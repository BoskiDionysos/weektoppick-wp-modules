
=== WTP Push Runner (Fixed) ===
Version: 0.2.0
Description: Runner instalacji ZIP przez lokalny Bridge /wp-json/wtp/v1/agent/install z podpisem HMAC. Logi + przycisk Uruchom teraz.
