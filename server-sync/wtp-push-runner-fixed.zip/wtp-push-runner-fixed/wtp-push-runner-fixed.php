<?php
/*
Plugin Name: WTP Push Runner (Fixed, hotfix)
Description: Agent instalacji ZIP z manifestu + LiteSpeed purge + logi + inventory + sync WP→GitHub. Wersja hotfix: bezpieczne ładowanie, brak fatali przy starcie.
Version: 1.1.2-hotfix
Author: WeekTopPick Autopilot
*/

if (!defined('ABSPATH')) { exit; }

class WTP_Push_Runner_Fixed {
    const OPT       = 'wtp_pr_settings';
    const LOG       = 'wtp_pr_log';
    const NONCE     = 'wtp_pr_nonce';
    const CRON_HOOK = 'wtp_pr_cron_event';

    // REST
    const REST_NS     = 'wtp-runner/v1';
    const R_INSTALL   = '/install';
    const R_PURGE     = '/purge';
    const R_HEALTH    = '/health';
    const R_LOGS      = '/logs';
    const R_LOGSCLR   = '/logs/clear';
    const R_INVENTORY = '/inventory';
    const R_SYNC      = '/sync';

    public function __construct() {
        add_action('admin_menu', [$this,'menu']);
        add_action('admin_init', [$this,'maybe_run_manual']);
        add_action('admin_post_wtp_pr_run_now',   [$this,'handle_run_now']);
        add_action('admin_post_wtp_pr_purge_now', [$this,'handle_purge_now']);
        add_action('admin_post_wtp_pr_sync_now',  [$this,'handle_sync_now']);
        add_action('admin_post_wtp_pr_logs_clear',[$this,'handle_logs_clear']);

        add_action(self::CRON_HOOK, [$this,'run']);
        add_filter('cron_schedules', [$this,'cron_schedules']);
        add_action('rest_api_init', [$this,'register_rest']);

        register_activation_hook(__FILE__, [$this,'activate']);
        register_deactivation_hook(__FILE__, [$this,'deactivate']);
    }

    /* =============== Settings & helpers =============== */

    public static function get_settings() {
        $defaults = [
            'manifest_url' => '',
            'api_key'      => '',
            'hmac_secret'  => '',
            'interval'     => 15,
            'enabled'      => 0,
            'runner_token' => '',
            'sync_repo'    => 'BoskiDionysos/weektoppick-wp-modules',
            'sync_branch'  => 'main',
        ];
        $opt = get_option(self::OPT, []);
        return wp_parse_args(is_array($opt)?$opt:[], $defaults);
    }
    public static function save_settings($data) { update_option(self::OPT, $data, false); }

    private static function token_runner() {
        // preferuj ENV z wp-config (WTP_AGENT_TOKEN), potem fallback z opcji UI
        $env = getenv('WTP_AGENT_TOKEN');
        if (!empty($env)) return trim($env);
        $s = self::get_settings();
        return isset($s['runner_token']) ? trim((string)$s['runner_token']) : '';
    }

    /** POPRAWKA: pobieranie PAT z ENV *i* stałych; przycięcie białych znaków */
    private static function token_github() {
        // ENV ustawiane w wp-config przez putenv
        $env1 = getenv('WTP_GH_SYNC_PAT') ?: '';
        $env2 = getenv('WTP_GITHUB_PAT')  ?: '';

        // stałe (gdy hosting nie wystawia ENV do PHP)
        $c1 = defined('WTP_GH_SYNC_PAT') ? (string)constant('WTP_GH_SYNC_PAT') : '';
        $c2 = defined('WTP_GITHUB_PAT')  ? (string)constant('WTP_GITHUB_PAT')  : '';

        $pat = $env1 ?: $env2 ?: $c1 ?: $c2 ?: '';

        // młotek na przypadkowe spacje/nowe linie ze schowka
        $pat = trim(preg_replace('/\s+/', '', (string)$pat));

        return $pat;
    }

    public function activate()  { $this->maybe_schedule(); }
    public function deactivate(){ wp_clear_scheduled_hook(self::CRON_HOOK); }

    public function cron_schedules($schedules) {
        foreach ([5,10,15,30] as $m) {
            $schedules['wtp_pr_every_'.$m.'_minutes'] = [ 'interval'=>$m*60, 'display'=>"Every $m minutes (WTP Push Runner)" ];
        }
        return $schedules;
    }
    private function maybe_schedule() {
        $s = self::get_settings();
        wp_clear_scheduled_hook(self::CRON_HOOK);
        if (!empty($s['enabled'])) {
            $interval = max(5, (int)$s['interval']);
            $key = 'wtp_pr_every_'.$interval.'_minutes';
            if (!wp_next_scheduled(self::CRON_HOOK))
                wp_schedule_event(time()+30, $key, self::CRON_HOOK);
        }
    }

    private static function add_log($action,$result,$details='') {
        $log = get_option(self::LOG, []);
        if (!is_array($log)) $log=[];
        array_unshift($log, [
            'time'=> current_time('mysql', true),
            'action'=>$action,
            'result'=>$result,
            'details'=> is_string($details)? $details : wp_json_encode($details, JSON_UNESCAPED_SLASHES),
        ]);
        update_option(self::LOG, array_slice($log,0,300), false);
    }

    private static function recently_done($k) {
        $key = 'wtp_pr_done_'.md5($k);
        if (get_transient($key)) return true;
        set_transient($key, time(), HOUR_IN_SECONDS);
        return false;
    }

    private static function bridge_path() { return '/wp-json/wtp/v1/agent/install'; }
    private static function bridge_full() { return rtrim(home_url(),'/').self::bridge_path(); }

    private static function ls_purge_all() {
        if (function_exists('do_action')) {
            do_action('litespeed_purge_all');
            self::add_log('purge','ok','litespeed_purge_all');
        }
    }
    private static function human_bytes($bytes) {
        $bytes = (float)$bytes;
        $units = ['B','KB','MB','GB','TB'];
        $i = 0;
        while ($bytes >= 1024 && $i < count($units)-1) { $bytes /= 1024; $i++; }
        return sprintf('%.1f&nbsp;%s', $bytes, $units[$i]);
    }

    /* =============== Admin screen =============== */

    public function menu() {
        add_menu_page('WTP Push Runner','WTP Push Runner','manage_options','wtp-push-runner',[$this,'screen'],'dashicons-update',61);
    }

    public function screen() {
        if (!current_user_can('manage_options')) return;
        $s = self::get_settings();

        if (isset($_POST['wtp_pr_save']) && check_admin_referer(self::NONCE)) {
            $s['manifest_url'] = esc_url_raw($_POST['manifest_url'] ?? '');
            $s['api_key']      = sanitize_text_field($_POST['api_key'] ?? '');
            $s['hmac_secret']  = sanitize_text_field($_POST['hmac_secret'] ?? '');
            $s['interval']     = max(5, (int)($_POST['interval'] ?? 15));
            $s['enabled']      = !empty($_POST['enabled']) ? 1 : 0;
            $s['runner_token'] = sanitize_text_field($_POST['runner_token'] ?? '');
            $s['sync_repo']    = sanitize_text_field($_POST['sync_repo'] ?? '');
            $s['sync_branch']  = sanitize_text_field($_POST['sync_branch'] ?? '');
            self::save_settings($s);
            $this->maybe_schedule();
            self::add_log('save','ok','settings saved');
            echo '<div class="updated"><p>Zapisano.</p></div>';
        }

        $ep = function($r){ return esc_html( home_url('/wp-json/'.self::REST_NS.$r) ); };

        // inventory (lokalny snapshot – bez REST, bez sieci)
        $inventory = self::list_wtp_plugins();
        usort($inventory, function($a,$b){
            if (($b['active']??false) !== ($a['active']??false)) return ($b['active']?1:-1);
            return strcmp($a['slug']??'', $b['slug']??'');
        });
        ?>
        <div class="wrap">
            <h1>WTP Push Runner</h1>
            <p>Agent: manifest → install → purge. Dodatkowo: inventory i sync WP → GitHub.</p>

            <form method="post">
                <?php wp_nonce_field(self::NONCE); ?>
                <table class="form-table">
                    <tr><th>Default Manifest URL</th>
                        <td><input type="url" class="regular-text code" name="manifest_url" value="<?php echo esc_attr($s['manifest_url']); ?>" placeholder="https://raw.githubusercontent.com/&lt;org&gt;/&lt;repo&gt;/main/plugins/manifest.json"></td></tr>
                    <tr><th>Bridge API Key</th>
                        <td><input type="text" class="regular-text" name="api_key" value="<?php echo esc_attr($s['api_key']); ?>"></td></tr>
                    <tr><th>Bridge HMAC Secret</th>
                        <td><input type="text" class="regular-text" name="hmac_secret" value="<?php echo esc_attr($s['hmac_secret']); ?>"></td></tr>
                    <tr><th>Runner token (fallback ENV)</th>
                        <td><input type="text" class="regular-text" name="runner_token" value="<?php echo esc_attr($s['runner_token']); ?>">
                            <p class="description">Preferowany ENV <code>WTP_AGENT_TOKEN</code> w wp-config.</p>
                        </td></tr>
                    <tr><th>Interwał (min)</th>
                        <td><input type="number" min="5" step="5" name="interval" value="<?php echo (int)$s['interval']; ?>">
                            &nbsp; <label><input type="checkbox" name="enabled" <?php checked($s['enabled'],1); ?>> Włączone (cron)</label>
                        </td></tr>
                    <tr><th>Repo do synchronizacji (WP → GitHub)</th>
                        <td>
                            <input type="text" class="regular-text code" name="sync_repo" value="<?php echo esc_attr($s['sync_repo']); ?>" placeholder="owner/repo">
                            <p class="description">Branch: <input type="text" name="sync_branch" value="<?php echo esc_attr($s['sync_branch']); ?>" size="10">. PAT w ENV/stałej: <code>WTP_GH_SYNC_PAT</code> lub <code>WTP_GITHUB_PAT</code>.</p>
                        </td></tr>
                </table>
                <p>
                    <button class="button button-primary" name="wtp_pr_save" value="1">Save Changes</button>
                    <a href="<?php echo esc_url( admin_url('admin-post.php?action=wtp_pr_run_now') ); ?>"   class="button">Uruchom teraz</a>
                    <a href="<?php echo esc_url( admin_url('admin-post.php?action=wtp_pr_purge_now') ); ?>" class="button">Wyczyść cache teraz</a>
                    <a href="<?php echo esc_url( admin_url('admin-post.php?action=wtp_pr_sync_now') ); ?>"  class="button">Sync WP → GitHub</a>
                    <a href="<?php echo esc_url( admin_url('admin-post.php?action=wtp_pr_logs_clear') ); ?>" class="button">Wyczyść log</a>
                </p>
            </form>

            <h3>Endpoints</h3>
            <ul>
                <li>Install: <code><?php echo $ep(self::R_INSTALL); ?></code></li>
                <li>Purge: <code><?php echo $ep(self::R_PURGE); ?></code></li>
                <li>Health: <code><?php echo $ep(self::R_HEALTH); ?></code></li>
                <li>Logs: <code><?php echo $ep(self::R_LOGS); ?>?secret=*&amp;n=100</code></li>
                <li>Inventory (REST): <code><?php echo $ep(self::R_INVENTORY); ?>?secret=*</code></li>
                <li>Sync WP → GitHub: <code><?php echo $ep(self::R_SYNC); ?></code> (POST JSON; alias GET dostępny)</li>
            </ul>

            <hr style="margin:24px 0">

            <h2 style="margin-bottom:10px;">Inventory (lokalny podgląd)</h2>
            <p class="description">Zrzut z dysku serwera (bez sieci). Pokazuje wszystkie wtyczki zaczynające się od <code>wtp-</code>.</p>

            <style>
                .wtp-inv-table td, .wtp-inv-table th { vertical-align: top; }
                .wtp-badge { display:inline-block; padding:2px 8px; border-radius:20px; font-size:11px; line-height:18px; font-weight:600; }
                .is-on  { background:#e6ffed; color:#067d26; border:1px solid #b7f5c6; }
                .is-off { background:#fff4e5; color:#8a4b00; border:1px solid #ffd8a8; }
                .mono { font-family: ui-monospace, Menlo, Monaco, Consolas, "Liberation Mono","Courier New", monospace; }
                .nowrap { white-space: nowrap; }
                .muted { color:#666; }
            </style>

            <?php $inventory = $inventory ?: []; ?>
            <table class="widefat striped fixed wtp-inv-table">
                <thead>
                    <tr>
                        <th style="width:180px;">Slug</th>
                        <th>Nazwa / Wersja</th>
                        <th style="width:90px;">Status</th>
                        <th style="width:110px;">Pliki</th>
                        <th style="width:120px;">Rozmiar</th>
                        <th>SHA256 (tree)</th>
                        <th>Ścieżka</th>
                    </tr>
                </thead>
                <tbody>
                <?php if (empty($inventory)): ?>
                    <tr><td colspan="7">Brak modułów <code>wtp-*</code> do wyświetlenia.</td></tr>
                <?php else: foreach ($inventory as $it): 
                    $hash = esc_html( substr($it['tree_sha256'] ?? '', 0, 12) . (empty($it['tree_sha256'])?'':'…') );
                    $ver  = esc_html($it['version'] ?? '');
                    $name = esc_html($it['name'] ?? $it['slug']);
                    $slug = esc_html($it['slug']);
                    $files= (int)($it['files'] ?? 0);
                    $bytes= (int)($it['bytes'] ?? 0);
                    $path = esc_html($it['path'] ?? '');
                    $active = !empty($it['active']);
                ?>
                    <tr>
                        <td class="mono"><?php echo $slug; ?></td>
                        <td><strong><?php echo $name; ?></strong><br><span class="muted">v<?php echo $ver ?: '—'; ?></span></td>
                        <td><?php if ($active): ?>
                            <span class="wtp-badge is-on">active</span>
                        <?php else: ?>
                            <span class="wtp-badge is-off">inactive</span>
                        <?php endif; ?></td>
                        <td class="nowrap"><?php echo number_format_i18n($files); ?></td>
                        <td class="nowrap"><?php echo self::human_bytes($bytes); ?></td>
                        <td class="mono"><?php echo $hash ?: '—'; ?></td>
                        <td class="mono"><?php echo $path ?: '—'; ?></td>
                    </tr>
                <?php endforeach; endif; ?>
                </tbody>
            </table>

            <h2 style="margin-top:28px;">Ostatnie wywołania</h2>
            <?php $log = get_option(self::LOG, []); if (empty($log)): ?>
                <p>Brak wpisów.</p>
            <?php else: ?>
                <table class="widefat striped"><thead><tr><th>Time (UTC)</th><th>Action</th><th>Result</th><th>Details</th></tr></thead><tbody>
                <?php foreach ($log as $row): ?>
                    <tr>
                        <td><?php echo esc_html($row['time']); ?></td>
                        <td><?php echo esc_html($row['action']); ?></td>
                        <td><?php echo esc_html($row['result']); ?></td>
                        <td><code style="white-space:pre-wrap;display:block;max-height:10em;overflow:auto;"><?php echo esc_html(is_string($row['details'])?$row['details']:wp_json_encode($row['details'])); ?></code></td>
                    </tr>
                <?php endforeach; ?>
                </tbody></table>
            <?php endif; ?>
        </div>
        <?php
    }

    /* =============== Manual triggers =============== */
    public function handle_run_now()   { if (!current_user_can('manage_options')) wp_die('forbidden'); $this->run(true);  wp_safe_redirect( admin_url('admin.php?page=wtp-push-runner') ); exit; }
    public function handle_purge_now() { if (!current_user_can('manage_options')) wp_die('forbidden'); self::ls_purge_all(); wp_safe_redirect( admin_url('admin.php?page=wtp-push-runner') ); exit; }
    public function maybe_run_manual() { /* noop */ }

    public function handle_logs_clear() {
        if (!current_user_can('manage_options')) wp_die('forbidden');
        update_option(self::LOG, [], false);
        wp_safe_redirect( admin_url('admin.php?page=wtp-push-runner') ); exit;
    }

    public function handle_sync_now() {
        if (!current_user_can('manage_options')) wp_die('forbidden');

        // Zbuduj wewnętrzne żądanie do istniejącej metody REST bez HTTP.
        $req = new WP_REST_Request('POST', '/'.self::REST_NS.self::R_SYNC);
        $req->set_param('secret', self::token_runner());
        $s = self::get_settings();
        if (!empty($s['sync_repo']))   $req->set_param('repo',   $s['sync_repo']);
        if (!empty($s['sync_branch'])) $req->set_param('branch', $s['sync_branch']);

        $resp = $this->rest_sync($req);

        nocache_headers();
        header('Content-Type: application/json; charset=utf-8');
        echo wp_json_encode([
            'ok'       => ($resp instanceof WP_REST_Response) ? (bool)($resp->get_status() === 200) : false,
            'response' => ($resp instanceof WP_REST_Response) ? $resp->get_data() : (string)$resp,
        ], JSON_UNESCAPED_SLASHES);
        exit;
    }

    /* =============== Core install =============== */

    private static function hmac_signature($ts,$path,$body,$secret) {
        $canonical = $ts."\n".'POST'."\n".$path."\n".$body;
        return hash_hmac('sha256',$canonical,(string)$secret);
    }

    public function run($manual=false,$override_manifest_url=null) {
        $s = self::get_settings();
        $summary = ['sent'=>0,'skipped'=>0,'errors'=>0];

        $manifest_url = $override_manifest_url ?: ($s['manifest_url'] ?? '');
        if (!$manifest_url) { self::add_log('run','fail','missing manifest_url'); return $summary; }

        self::add_log('run','start','GET '.$manifest_url);
        $resp = wp_remote_get($manifest_url,['timeout'=>30]);
        if (is_wp_error($resp)) { $summary['errors']++; self::add_log('manifest','error',$resp->get_error_message()); return $summary; }
        $code = wp_remote_retrieve_response_code($resp);
        $body = wp_remote_retrieve_body($resp);
        self::add_log('manifest','http '.$code, substr((string)$body,0,600));
        if ($code !== 200) { $summary['errors']++; return $summary; }

        $json = json_decode((string)$body,true);
        $plugins = [];
        if (isset($json['plugins']) && is_array($json['plugins'])) $plugins = $json['plugins'];
        elseif (is_array($json)) $plugins = $json;
        if (!$plugins) { $summary['errors']++; self::add_log('manifest','error','invalid json/plugins'); return $summary; }

        foreach ($plugins as $p) {
            if (empty($p['url'])) continue;
            $url = esc_url_raw($p['url']);
            $version = isset($p['version']) ? (string)$p['version'] : '';
            $dedupe = $version ? "$url|$version" : $url;
            if (self::recently_done($dedupe)) { $summary['skipped']++; self::add_log('install','skip',$url); continue; }

            $payload = wp_json_encode(['url'=>$url]);
            $ts = (string) time();
            $path = self::bridge_path();
            $sig  = self::hmac_signature($ts,$path,$payload,$s['hmac_secret']);
            $headers = [
                'Content-Type'    => 'application/json; charset=utf-8',
                'X-WTP-Key'       => $s['api_key'],
                'X-WTP-Timestamp' => $ts,
                'X-WTP-Signature' => $sig,
            ];
            $endpoint = self::bridge_full();
            $r = wp_remote_post($endpoint,['timeout'=>45,'headers'=>$headers,'body'=>$payload]);
            if (is_wp_error($r)) { $summary['errors']++; self::add_log('install','error',$url.' :: '.$r->get_error_message()); continue; }
            $rcode = wp_remote_retrieve_response_code($r);
            $rbody = wp_remote_retrieve_body($r);
            $summary[ ($rcode>=200 && $rcode<300) ? 'sent' : 'errors' ]++;
            self::add_log('install','http '.$rcode, $url.' :: '.substr((string)$rbody,0,800));
        }

        self::ls_purge_all();
        self::add_log('summary','done',$summary);
        return $summary;
    }

    /* =============== Inventory & Sync (defensive) =============== */

    private static function list_wtp_plugins() {
        if (!function_exists('get_plugins')) {
            require_once ABSPATH.'wp-admin/includes/plugin.php';
        }
        $all = function_exists('get_plugins') ? get_plugins() : [];
        $out = [];
        foreach ($all as $file=>$header) {
            $slug = explode('/', $file)[0];
            if (strpos($slug,'wtp-') !== 0) continue;
            $dir = WP_PLUGIN_DIR . '/' . $slug;

            $hash = @hash_init('sha256');
            $count = 0; $size = 0;

            if (is_dir($dir) && class_exists('RecursiveDirectoryIterator') && function_exists('hash_update_file')) {
                try {
                    $rii = new RecursiveIteratorIterator(new RecursiveDirectoryIterator($dir, FilesystemIterator::SKIP_DOTS));
                    foreach ($rii as $f) {
                        /** @var SplFileInfo $f */
                        if ($f->isFile()) {
                            $path = $f->getRealPath();
                            if (strpos($path,'/.git/')!==false || strpos($path,'/node_modules/')!==false) continue;
                            $count++; $size += (int)@filesize($path);
                            @hash_update_file($hash, $path);
                        }
                    }
                } catch (\Throwable $e) {
                    self::add_log('inventory','warn','iter_error: '.$e->getMessage());
                }
            }
            $treeSha = $hash ? @hash_final($hash,false) : '';
            $out[] = [
                'slug'    => $slug,
                'name'    => $header['Name'] ?? $slug,
                'version' => $header['Version'] ?? '',
                'active'  => function_exists('is_plugin_active') ? is_plugin_active($file) : false,
                'path'    => $file,
                'files'   => $count,
                'bytes'   => $size,
                'tree_sha256' => $treeSha ?: '',
            ];
        }
        return $out;
    }

    private static function make_zip($slug) {
        $dir = WP_PLUGIN_DIR . '/' . $slug;
        if (!is_dir($dir)) return new WP_Error('no_dir','Plugin dir not found: '.$slug);

        $tmp = wp_tempnam($slug.'.zip'); if (!$tmp) return new WP_Error('tmp','temp fail');
        if (file_exists($tmp)) @unlink($tmp);

        if (class_exists('ZipArchive')) {
            try {
                $zip = new ZipArchive();
                if ($zip->open($tmp, ZipArchive::CREATE)!== true) return new WP_Error('zip','Zip open fail');
                $rii = new RecursiveIteratorIterator(new RecursiveDirectoryIterator($dir, FilesystemIterator::SKIP_DOTS));
                foreach ($rii as $f) {
                    /** @var SplFileInfo $f */
                    if ($f->isFile()) {
                        $path = $f->getRealPath();
                        if (strpos($path,'/.git/')!==false || strpos($path,'/node_modules/')!==false) continue;
                        $rel  = substr($path, strlen(dirname($dir)) + 1);
                        $zip->addFile($path, $rel);
                    }
                }
                $zip->close();
            } catch (\Throwable $e) {
                return new WP_Error('zip','zip_throwable: '.$e->getMessage());
            }
        } elseif (class_exists('PharData')) {
            try {
                $tmp = preg_replace('/\.zip$/','.tar', $tmp);
                $phar = new PharData($tmp);
                $phar->buildFromDirectory($dir);
            } catch (\Throwable $e) {
                return new WP_Error('tar','tar_throwable: '.$e->getMessage());
            }
        } else {
            return new WP_Error('archiver','no_zip_phar');
        }
        return $tmp;
    }

    /** POPRAWKA: Authorization: Bearer <PAT> */
    private static function github_put_file($repo,$branch,$path,$content_b64,$message,$pat) {
        $url = "https://api.github.com/repos/$repo/contents/".ltrim($path,'/');
        $headers = [
            'Authorization' => 'Bearer '.$pat,
            'User-Agent'    => 'wtp-runner',
            'Content-Type'  => 'application/json',
            'Accept'        => 'application/vnd.github+json',
        ];
        $existing = wp_remote_get($url."?ref=".rawurlencode($branch), ['headers'=>$headers, 'timeout'=>20]);
        $sha = null;
        if (!is_wp_error($existing) && wp_remote_retrieve_response_code($existing) === 200) {
            $j = json_decode(wp_remote_retrieve_body($existing), true);
            $sha = $j['sha'] ?? null;
        }
        $body = [
            'message' => $message,
            'content' => $content_b64,
            'branch'  => $branch,
        ];
        if ($sha) $body['sha'] = $sha;
        return wp_remote_request($url, [
            'method'=>'PUT',
            'headers'=>$headers,
            'timeout'=>30,
            'body'=> wp_json_encode($body),
        ]);
    }

    /* =============== REST =============== */

    public function register_rest() {
        // Health
        register_rest_route(self::REST_NS, self::R_HEALTH, [
            'methods'=>'GET','permission_callback'=>'__return_true',
            'callback'=>function(){
                return new WP_REST_Response([
                    'ok'=>true,
                    'runner'=>'wtp-push-runner-fixed-hotfix',
                    'token_source'=> getenv('WTP_AGENT_TOKEN') ? 'env' : 'option',
                    'time_utc'=> current_time('mysql', true),
                    'bridge'=> ['path'=>self::bridge_path(),'full'=>self::bridge_full()],
                ],200);
            }
        ]);

        register_rest_route(self::REST_NS, self::R_INSTALL, [
            'methods'=>'POST', 'callback'=>[$this,'rest_install'], 'permission_callback'=>'__return_true',
            'args'=>['secret'=>['required'=>true],'manifest'=>['required'=>false]],
        ]);
        register_rest_route(self::REST_NS, self::R_PURGE, [
            'methods'=>'POST','permission_callback'=>'__return_true',
            'callback'=>function(WP_REST_Request $req){
                if ($this->deny($req)) return $this->unauth();
                self::ls_purge_all(); return new WP_REST_Response(['ok'=>true,'action'=>'purged'],200);
            }
        ]);
        register_rest_route(self::REST_NS, self::R_LOGS, [
            'methods'=>'GET','permission_callback'=>'__return_true',
            'args'=>['secret'=>['required'=>true],'n'=>['required'=>false]],
            'callback'=>function(WP_REST_Request $req){
                if ($this->deny($req)) return $this->unauth();
                $n = max(1, min(200, (int)($req->get_param('n') ?: 50)));
                $log = get_option(self::LOG, []);
                return new WP_REST_Response(['ok'=>true,'items'=>is_array($log)?array_slice($log,0,$n):[]],200);
            }
        ]);
        register_rest_route(self::REST_NS, self::R_LOGSCLR, [
            'methods'=>'POST','permission_callback'=>'__return_true',
            'args'=>['secret'=>['required'=>true]],
            'callback'=>function(WP_REST_Request $req){
                if ($this->deny($req)) return $this->unauth();
                update_option(self::LOG, [], false);
                return new WP_REST_Response(['ok'=>true,'cleared'=>true],200);
            }
        ]);
        register_rest_route(self::REST_NS, self::R_INVENTORY, [
            'methods'=>'GET','permission_callback'=>'__return_true',
            'args'=>['secret'=>['required'=>true]],
            'callback'=>function(WP_REST_Request $req){
                if ($this->deny($req)) return $this->unauth();
                $items = self::list_wtp_plugins();
                return new WP_REST_Response(['ok'=>true,'count'=>count($items),'items'=>$items],200);
            }
        ]);
        register_rest_route(self::REST_NS, self::R_SYNC, [
            'methods'=>'POST','permission_callback'=>'__return_true',
            'args'=>['secret'=>['required'=>true],'repo'=>['required'=>false],'branch'=>['required'=>false]],
            'callback'=>[$this,'rest_sync'],
        ]);
        // Alias GET dla /sync – szybki test z przeglądarki
        register_rest_route(self::REST_NS, self::R_SYNC, [
            'methods'=>'GET','permission_callback'=>'__return_true',
            'args'=>[
                'secret'=>['required'=>true],
                'repo'  =>['required'=>false],
                'branch'=>['required'=>false],
            ],
            'callback'=>[$this,'rest_sync'],
        ]);
    }

    private function deny(WP_REST_Request $req){ return !hash_equals(self::token_runner() ?: '', (string)$req->get_param('secret')); }
    private function unauth(){ return new WP_REST_Response(['ok'=>false,'error'=>'unauthorized'],401); }

    public function rest_install(WP_REST_Request $req) {
        if ($this->deny($req)) return $this->unauth();
        $manifest = (string)$req->get_param('manifest');
        $summary  = $this->run(false, $manifest ?: null);
        self::ls_purge_all();
        return new WP_REST_Response(['ok'=>true,'summary'=>$summary],200);
    }

    public function rest_sync(WP_REST_Request $req) {
        if ($this->deny($req)) return $this->unauth();

        $s = self::get_settings();
        $repo   = $req->get_param('repo')   ?: $s['sync_repo'];
        $branch = $req->get_param('branch') ?: $s['sync_branch'];
        $pat    = self::token_github();
        if (!$repo || !$pat) { self::add_log('sync','fail','missing repo or PAT'); return new WP_REST_Response(['ok'=>false,'error'=>'missing repo or PAT'],400); }

        $items = self::list_wtp_plugins();
        $index = ['generated_utc'=>current_time('mysql',true),'plugins'=>[]];
        $errors = 0; $uploaded = 0;

        foreach ($items as $it) {
            $slug = $it['slug'];
            $zip = self::make_zip($slug);
            if (is_wp_error($zip)) { $errors++; self::add_log('sync','zip_error', $slug.' :: '.$zip->get_error_message()); continue; }
            $data = @file_get_contents($zip);
            @unlink($zip);
            if (!$data) { $errors++; self::add_log('sync','zip_empty',$slug); continue; }
            $b64 = base64_encode($data);

            $path = "server-sync/$slug.zip";
            $msg  = "runner: sync $slug from WP";
            $res  = self::github_put_file($repo,$branch,$path,$b64,$msg,$pat);
            $code = is_wp_error($res) ? 0 : (int)wp_remote_retrieve_response_code($res);
            if (is_wp_error($res) || $code < 200 || $code >= 300) {
                $errors++;
                self::add_log('sync','upload_fail', $slug.' :: '.(is_wp_error($res)?$res->get_error_message():wp_remote_retrieve_body($res)));
                continue;
            }
            $uploaded++;
            $index['plugins'][] = $it + ['artifact_path'=>$path];
            self::add_log('sync','uploaded',$slug);
        }

        $index_json = wp_json_encode($index, JSON_UNESCAPED_SLASHES);
        $resIndex = self::github_put_file($repo,$branch,'server-sync/index.json', base64_encode($index_json), 'runner: update server-sync index', $pat);
        $codeI = is_wp_error($resIndex) ? 0 : (int)wp_remote_retrieve_response_code($resIndex);
        if (is_wp_error($resIndex) || $codeI < 200 || $codeI >= 300) {
            $errors++;
            self::add_log('sync','index_fail', is_wp_error($resIndex)?$resIndex->get_error_message():wp_remote_retrieve_body($resIndex));
        } else {
            self::add_log('sync','index_ok','server-sync/index.json');
        }

        return new WP_REST_Response(['ok'=>($errors===0),'uploaded'=>$uploaded,'errors'=>$errors,'index'=>'server-sync/index.json'], ($errors?207:200));
    }
}

new WTP_Push_Runner_Fixed();