<?php
/**
 * Plugin Name: WTP URL Tester
 * Description: Test URLs (status, redirects, response time) with optional hreflang extraction. Admin UI + REST API + JSON export. Mobile-first. Includes one-click REST self-test.
 * Version: 1.2.1
 * Author: WeekTopPick Autopilot
 * License: GPLv2 or later
 */

if ( ! defined( 'ABSPATH' ) ) exit;

class WTP_URL_Tester {
    const SLUG = 'wtp-url-tester';
    const CAP  = 'edit_posts';
    const REST_NS = 'wtp/v1';
    const REST_ROUTE = '/urltester';

    public function __construct() {
        add_action('admin_menu', [$this, 'admin_menu']);
        add_action('admin_enqueue_scripts', [$this, 'enqueue']);
        add_action('rest_api_init', [$this, 'register_rest']);
    }

    public function admin_menu() {
        add_menu_page(
            'WTP URL Tester',
            'WTP URL Tester',
            self::CAP,
            self::SLUG,
            [$this, 'render_page'],
            'dashicons-admin-links',
            56
        );
    }

    public function enqueue($hook) {
        if ($hook !== 'toplevel_page_' . self::SLUG) return;
        wp_enqueue_style(self::SLUG, plugins_url('admin.css', __FILE__), [], '1.2.1');
        wp_enqueue_script(self::SLUG, plugins_url('admin.js', __FILE__), ['wp-api-fetch'], '1.2.1', true);
        wp_localize_script(self::SLUG, 'WTPURLTester', [
            'restUrl' => esc_url_raw( rest_url( self::REST_NS . self::REST_ROUTE ) ),
            'nonce'   => wp_create_nonce('wp_rest'),
            'home'    => home_url('/'),
        ]);
    }

    public function render_page() { ?>
        <div class="wrap wtp-url-tester">
            <h1>WTP URL Tester</h1>

            <div class="notice notice-info">
                <p>Enter relative paths (e.g., <code>/</code>, <code>/pl/</code>, <code>/sitemap_index.xml</code>) or absolute URLs. The tester will resolve paths against <strong><?php echo esc_html(home_url('/')); ?></strong>, follow redirects (up to 10), measure response times, and optionally extract <code>hreflang</code> from the final page.</p>
            </div>

            <label for="wtp-urls" class="screen-reader-text">Paths or URLs</label>
            <textarea id="wtp-urls" rows="6" placeholder="/
/pl/
/sitemap_index.xml"></textarea>

            <p class="checkbox">
                <label><input type="checkbox" id="wtp-hreflang" /> Extract hreflang tags from the final page (if HTML)</label>
            </p>

            <p class="actions">
                <button id="wtp-run" class="button button-primary">Test URLs</button>
                <button id="wtp-download" class="button" disabled>Download JSON</button>
                <button id="wtp-selftest" class="button">REST self-test</button>
                <span id="wtp-status" class="status"></span>
            </p>

            <div id="wtp-selftest-result" class="selftest hidden"></div>

            <div id="wtp-results" class="results is-empty">
                <table class="widefat fixed striped">
                    <thead>
                        <tr>
                            <th>Input</th>
                            <th>Final URL</th>
                            <th>Status</th>
                            <th class="col-time">Time (ms)</th>
                            <th class="col-chain">Redirects</th>
                            <th class="col-hreflang">Hreflang (count)</th>
                        </tr>
                    </thead>
                    <tbody></tbody>
                </table>
            </div>

            <p class="help">
                REST: <code><?php echo esc_html( rest_url( self::REST_NS . self::REST_ROUTE ) ); ?></code><br>
                Method: <code>POST</code>, Body: <code>{"urls":["/","/pl/"],"hreflang":true}</code> (requires capability <code><?php echo esc_html(self::CAP); ?></code>)
            </p>
        </div>
    <?php }

    public function register_rest() {
        register_rest_route(self::REST_NS, self::REST_ROUTE, [
            'methods'  => 'POST',
            'callback' => [$this, 'rest_test_urls'],
            'permission_callback' => function() {
                return current_user_can(self::CAP);
            }
        ]);
    }

    private function is_absolute_url($url) {
        return (bool) preg_match('#^https?://#i', $url);
    }

    private function resolve_url($input) {
        $input = trim($input);
        if ($input === '') return '';
        if ($this->is_absolute_url($input)) return $input;
        $home = home_url('/');
        if ($input[0] === '/') {
            return esc_url_raw( rtrim($home, '/') . $input );
        }
        return esc_url_raw( $home . ltrim($input, '/') );
    }

    private function fetch_once($url, $method='GET') {
        $start = microtime(true);
        $resp = wp_remote_request($url, [
            'method' => $method,
            'timeout' => 10,
            'redirection' => 0,
            'headers' => [
                'User-Agent' => 'WTP-URL-Tester/1.2.1 (+'.home_url('/').')'
            ]
        ]);
        $elapsed = (int) round((microtime(true) - $start) * 1000);
        if (is_wp_error($resp)) {
            return [
                'error' => $resp->get_error_message(),
                'time_ms' => $elapsed,
                'status' => 0,
                'headers' => []
            ];
        }
        return [
            'response' => $resp,
            'time_ms'  => $elapsed,
            'status'   => intval(wp_remote_retrieve_response_code($resp)),
            'headers'  => wp_remote_retrieve_headers($resp),
            'body'     => wp_remote_retrieve_body($resp),
        ];
    }

    private function follow_redirects($url, $max=10) {
        $chain = [];
        $total_time = 0;
        $current = $url;
        for ($i=0; $i<$max; $i++) {
            $res = $this->fetch_once($current, 'GET');
            $time = isset($res['time_ms']) ? intval($res['time_ms']) : 0;
            $total_time += $time;
            $status = isset($res['status']) ? intval($res['status']) : 0;
            $location = '';
            if (isset($res['headers']['location'])) {
                $location = $res['headers']['location'];
                if (! $this->is_absolute_url($location)) {
                    $p = wp_parse_url($current);
                    $scheme = isset($p['scheme']) ? $p['scheme'] : 'https';
                    $host = $p['host'];
                    $port = isset($p['port']) ? ':'.$p['port'] : '';
                    if (strpos($location, '/') === 0) {
                        $location = $scheme.'://'.$host.$port.$location;
                    } else {
                        $base = trailingslashit($current);
                        $location = $base . ltrim($location, '/');
                    }
                }
            }
            $chain[] = [
                'url' => $current,
                'status' => $status,
                'time_ms' => $time,
                'location' => $location,
            ];
            if ($status >= 300 && $status < 400 && !empty($location)) {
                $current = $location;
                continue;
            }
            $final = $current;
            $body  = isset($res['body']) ? $res['body'] : '';
            return [
                'final_url' => $final,
                'status' => $status,
                'total_time_ms' => $total_time,
                'chain' => $chain,
                'body' => $body,
                'error' => isset($res['error']) ? $res['error'] : null
            ];
        }
        return [
            'final_url' => $current,
            'status' => 310,
            'total_time_ms' => $total_time,
            'chain' => $chain,
            'body' => '',
            'error' => 'Too many redirects'
        ];
    }

    private function parse_hreflang($html) {
        $out = [];
        if (!is_string($html) || $html === '') return $out;
        if (preg_match_all('#<link[^>]+rel=["\']alternate["\'][^>]*>#i', $html, $links)) {
            foreach ($links[0] as $tag) {
                $hreflang = '';
                $href = '';
                if (preg_match('#hreflang=["\']([^"\']+)#i', $tag, $m1)) $hreflang = trim($m1[1]);
                if (preg_match('#href=["\']([^"\']+)#i', $tag, $m2)) $href = trim($m2[1]);
                if ($hreflang && $href) $out[] = ['hreflang' => $hreflang, 'href' => $href];
            }
        }
        return $out;
    }

    public function rest_test_urls(\WP_REST_Request $req) {
        $urls = $req->get_param('urls');
        $want_hreflang = (bool) $req->get_param('hreflang');
        if (!is_array($urls) || empty($urls)) {
            return new \WP_Error('bad_request', 'Provide non-empty array of URLs', ['status' => 400]);
        }
        $results = [];
        foreach ($urls as $raw) {
            $input = trim((string)$raw);
            if ($input === '') continue;
            $resolved = $this->resolve_url($input);
            $follow = $this->follow_redirects($resolved, 10);
            $entry = [
                'input' => $input,
                'resolved' => $resolved,
                'final_url' => $follow['final_url'],
                'status' => $follow['status'],
                'time_ms' => $follow['total_time_ms'],
                'chain' => $follow['chain'],
                'error' => $follow['error'],
            ];
            if ($want_hreflang && $follow['status'] == 200 && !empty($follow['body'])) {
                $entry['hreflang'] = $this->parse_hreflang($follow['body']);
            }
            $results[] = $entry;
        }
        return [
            'site' => home_url('/'),
            'generated_at' => gmdate('c'),
            'hreflang' => $want_hreflang,
            'count' => count($results),
            'results' => $results
        ];
    }
}

new WTP_URL_Tester();
