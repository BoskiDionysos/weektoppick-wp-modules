WTP URL Tester v1.2.1
======================
Adds a one-click "REST self-test" in the admin screen.

REST:
POST /wp-json/wtp/v1/urltester
Body: {"urls":["/","/pl/"], "hreflang": true}
Requires capability: edit_posts

Admin UI:
- Test URLs
- Download JSON
- REST self-test (verifies POST endpoint end-to-end)
