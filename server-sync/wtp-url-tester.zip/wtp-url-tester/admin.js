(function(){
  const $ = (sel)=>document.querySelector(sel);

  function parseTextarea(val){ return val.split(/\r?\n/).map(s=>s.trim()).filter(Boolean); }
  function setStatus(msg){ $('#wtp-status').textContent = msg || ''; }

  async function postJson(url, body){
    const res = await fetch(url, {
      method: 'POST',
      headers: {'Content-Type':'application/json','X-WP-Nonce': WTPURLTester.nonce},
      body: JSON.stringify(body||{})
    });
    if (!res.ok){ throw new Error('REST '+res.status+': '+await res.text()); }
    return res.json();
  }

  async function run(){
    const urls = parseTextarea($('#wtp-urls').value);
    if (!urls.length){ alert('Please enter at least one URL path or absolute URL.'); return; }
    setStatus('Running…'); $('#wtp-download').disabled = true;
    try {
      const data = await postJson(WTPURLTester.restUrl, { urls, hreflang: $('#wtp-hreflang').checked });
      render(data); window._wtp_last_json = data; $('#wtp-download').disabled = false; setStatus('Done');
    } catch(e){ console.error(e); alert(e.message||e); setStatus('Error'); }
  }

  function render(data){
    const tbody = document.querySelector('#wtp-results tbody'); tbody.innerHTML='';
    (data.results||[]).forEach(r=>{
      const tr = document.createElement('tr');
      tr.innerHTML = `
        <td><code>${esc(r.input)}</code></td>
        <td><a href="${attr(r.final_url)}" target="_blank" rel="noopener">${esc(r.final_url)}</a></td>
        <td class="${r.status===200?'ok':'fail'}">${r.status}</td>
        <td class="col-time">${r.time_ms ?? ''}</td>
        <td class="col-chain">${(r.chain||[]).map(c=>`${c.status} → ${esc(c.location||'')}`).join('<br>')}</td>
        <td class="col-hreflang">${(r.hreflang||[]).length||''}</td>`;
      tbody.appendChild(tr);
    });
    document.querySelector('#wtp-results').classList.toggle('is-empty',(data.results||[]).length===0);
  }

  function esc(s){ return String(s||'').replace(/[&<>"']/g, m => ({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;'}[m])); }
  function attr(s){ return esc(s).replace(/"/g,'&quot;'); }

  function download(){
    const data = window._wtp_last_json; if (!data){ alert('Run a test first.'); return; }
    const blob = new Blob([JSON.stringify(data,null,2)],{type:'application/json'});
    const url = URL.createObjectURL(blob); const a = document.createElement('a');
    a.href = url; a.download = `wtp-url-tester-results-${new Date().toISOString().replace(/[:.]/g,'-')}.json`;
    document.body.appendChild(a); a.click(); setTimeout(()=>{ URL.revokeObjectURL(url); a.remove(); },0);
  }

  async function selftest(){
    setStatus('Self-testing…'); const el = $('#wtp-selftest-result'); el.classList.add('hidden'); el.classList.remove('error');
    try {
      const data = await postJson(WTPURLTester.restUrl, { urls: ['/','/robots.txt'], hreflang: false });
      const ok = data && data.results && data.results.length===2 && data.results.every(r=>typeof r.status==='number');
      el.textContent = ok ? 'REST self-test: PASS (endpoint responds to POST with valid JSON).' : 'REST self-test: FAIL (unexpected response).';
      el.classList.toggle('error', !ok); el.classList.remove('hidden'); setStatus('Done');
    } catch(e){
      el.textContent = 'REST self-test: FAIL — ' + (e.message||e);
      el.classList.add('error'); el.classList.remove('hidden'); setStatus('Error');
    }
  }

  document.addEventListener('DOMContentLoaded', function(){
    $('#wtp-run').addEventListener('click', run);
    $('#wtp-download').addEventListener('click', download);
    $('#wtp-selftest').addEventListener('click', selftest);
    if (!$('#wtp-urls').value.trim()){ $('#wtp-urls').value = "/\n/pl/\n/sitemap_index.xml\n/robots.txt"; }
  });
})();