<?php
/*
Plugin Name: WTP Agent Tester (Fixed)
Description: Tester dla WTP Agent Bridge (Enterprise). Poprawka: budowanie canonical string kropką (.) zamiast dodawania (+) oraz jawne rzutowanie timestamp na string.
Version: 0.3.1
Author: WeekTopPick
*/

if (!defined('ABSPATH')) { exit; }

class WTP_Agent_Tester_Fixed {
    const PAGE_SLUG = 'wtp-agent-tester';

    public function __construct() {
        add_action('admin_menu', [$this, 'menu']);
        add_action('admin_post_wtp_agent_ping', [$this, 'handle_ping']);
        add_action('admin_post_wtp_agent_install', [$this, 'handle_install']);
    }

    public function menu() {
        add_menu_page(
            'WTP Agent Tester (Enterprise)',
            'WTP Agent Tester',
            'manage_options',
            self::PAGE_SLUG,
            [$this, 'render'],
            'dashicons-admin-generic',
            59
        );
    }

    private function site_base() {
        return rtrim(get_site_url(), '/');
    }

    public function render() {
        if (!current_user_can('manage_options')) return;
        $site = esc_url($this->site_base());
        $ping = $site . '/wp-json/wtp/v1/agent/ping';
        $install = $site . '/wp-json/wtp/v1/agent/install';
        ?>
        <div class="wrap">
            <h1>WTP Agent Tester (Enterprise)</h1>
            <p>Symulator żądań do WTP Agent Bridge. Ta wersja zawiera poprawkę budowania <em>canonical string</em> (PHP 8.2+).</p>

            <h2>1) Ping (GET)</h2>
            <form method="post" action="<?php echo esc_url(admin_url('admin-post.php')); ?>">
                <table class="form-table">
                    <tr><th><label>Adres</label></th><td><input type="text" name="addr" class="regular-text" value="<?php echo esc_attr($ping); ?>" readonly></td></tr>
                    <tr><th><label>API Key</label></th><td><input type="text" name="api_key" class="regular-text" value=""></td></tr>
                    <tr><th><label>HMAC Secret (opcjonalnie)</label></th><td><input type="text" name="hmac" class="regular-text" value=""></td></tr>
                </table>
                <input type="hidden" name="action" value="wtp_agent_ping">
                <?php submit_button('Sprawdź ping'); ?>
            </form>

            <hr />

            <h2>2) Instalacja ZIP (POST /install)</h2>
            <form method="post" action="<?php echo esc_url(admin_url('admin-post.php')); ?>">
                <table class="form-table">
                    <tr><th><label>Endpoint</label></th><td><input type="text" name="endpoint" class="regular-text" value="<?php echo esc_attr($install); ?>" readonly></td></tr>
                    <tr><th><label>URL ZIP</label></th><td><input type="text" name="zip" class="regular-text" placeholder="https://example.com/downloads/plugin.zip"></td></tr>
                    <tr><th><label>API Key</label></th><td><input type="text" name="api_key" class="regular-text" value=""></td></tr>
                    <tr><th><label>HMAC Secret</label></th><td><input type="text" name="hmac" class="regular-text" value=""></td></tr>
                </table>
                <input type="hidden" name="action" value="wtp_agent_install">
                <?php submit_button('Wyślij instalację (symulacja PUSH)'); ?>
            </form>
        </div>
        <?php
    }

    public function handle_ping() {
        if (!current_user_can('manage_options')) wp_die('Forbidden');
        $addr = isset($_POST['addr']) ? esc_url_raw($_POST['addr']) : '';
        $api_key = isset($_POST['api_key']) ? sanitize_text_field($_POST['api_key']) : '';
        $hmac = isset($_POST['hmac']) ? sanitize_text_field($_POST['hmac']) : '';

        $headers = [];
        if (!empty($api_key)) $headers['X-WTP-Key'] = $api_key;

        if (!empty($hmac)) {
            $method = 'GET';
            $ts = (string) time();
            $path = parse_url($addr, PHP_URL_PATH);
            $body = '';
            $canonical = $ts . "\n" . $method . "\n" . $path . "\n" . $body;
            $sig = hash_hmac('sha256', $canonical, $hmac);
            $headers['X-WTP-Timestamp'] = $ts;
            $headers['X-WTP-Signature'] = $sig;
        }

        $resp = wp_remote_get($addr, ['headers' => $headers, 'timeout' => 20]);
        $this->render_response_and_exit($resp);
    }

    public function handle_install() {
        if (!current_user_can('manage_options')) wp_die('Forbidden');
        $endpoint = isset($_POST['endpoint']) ? esc_url_raw($_POST['endpoint']) : '';
        $zip = isset($_POST['zip']) ? esc_url_raw($_POST['zip']) : '';
        $api_key = isset($_POST['api_key']) ? sanitize_text_field($_POST['api_key']) : '';
        $hmac = isset($_POST['hmac']) ? sanitize_text_field($_POST['hmac']) : '';

        if (empty($endpoint) || empty($zip) || empty($api_key) || empty($hmac)) {
            wp_die('Brak wymaganych danych (endpoint/zip/api_key/hmac).');
        }

        $method = 'POST';
        $ts = (string) time();
        $path = parse_url($endpoint, PHP_URL_PATH);

        $payload = wp_json_encode(['url' => $zip]);
        if ($payload === false) $payload = '{"url":""}';

        $canonical = $ts . "\n" . $method . "\n" . $path . "\n" . $payload;
        $sig = hash_hmac('sha256', $canonical, $hmac);

        $headers = [
            'Content-Type'    => 'application/json',
            'X-WTP-Key'       => $api_key,
            'X-WTP-Timestamp' => $ts,
            'X-WTP-Signature' => $sig,
        ];

        $resp = wp_remote_post($endpoint, [
            'headers' => $headers,
            'body'    => $payload,
            'timeout' => 30,
        ]);

        $this->render_response_and_exit($resp);
    }

    private function render_response_and_exit($resp) {
        status_header(200);
        header('Content-Type: text/plain; charset=utf-8');
        if (is_wp_error($resp)) {
            echo "WP_Error: " . $resp->get_error_message();
        } else {
            echo "HTTP " . wp_remote_retrieve_response_code($resp) . " " . wp_remote_retrieve_response_message($resp) . "\n\n";
            $h = wp_remote_retrieve_headers($resp);
            if (!empty($h)) {
                echo "Headers:\n";
                foreach ($h as $k => $v) {
                    if (is_array($v)) $v = implode(', ', $v);
                    echo $k . ": " . $v . "\n";
                }
                echo "\n";
            }
            $body = wp_remote_retrieve_body($resp);
            echo $body;
        }
        exit;
    }
}

new WTP_Agent_Tester_Fixed();
?>