<?php
/**
 * Plugin Name: WTP Agent Bridge
 * Description: Most agent-ready (enterprise): API Key + HMAC podpis (X-WTP-Signature) + znacznik czasu (X-WTP-Timestamp). Z proxy do Module Managera. v0.2.2: pełne logi MM + retry z overwrite.
 * Version: 0.2.2
 * Author: WeekTopPick Autopilot
 * License: GPLv2 or later
 */

if ( ! defined('ABSPATH') ) exit;

class WTP_Agent_Bridge_Ent {
    const SLUG = 'wtp-agent-bridge';
    const OPTS = 'wtp_agent_bridge_opts';
    const LOG  = 'wtp_agent_bridge_log'; // max 200 wpisów

    public function __construct(){
        add_action('admin_menu', [$this,'menu']);
        add_action('admin_init', [$this,'register']);
        add_action('rest_api_init', [$this,'rest']);
    }

    public function menu(){
        add_menu_page('WTP Agent Bridge','WTP Agent', 'manage_options', self::SLUG, [$this,'render'], 'dashicons-rest-api', 58);
    }

    public function register(){
        register_setting(self::SLUG, self::OPTS);
        $o = get_option(self::OPTS, []);
        if (!is_array($o)) $o = [];
        $defaults = [
            'api_key' => wp_generate_password(32,false,false),
            'hmac_secret' => wp_generate_password(48,false,false),
            'require_signature' => true,
            'max_skew' => 300,
            'allow_ips' => "",
            'allow_hosts' => "",
            'enable_proxy_install' => true,
            'mm_api_key_override' => "", // NEW in 0.2.1
        ];
        update_option(self::OPTS, array_merge($defaults, $o), false);
    }

    private function log($action,$result,$details=''){
        $row = ['time'=>gmdate('c'),'action'=>$action,'result'=>$result,'details'=>$details];
        $log = get_option(self::LOG, []);
        if(!is_array($log)) $log=[];
        array_unshift($log,$row);
        $log = array_slice($log,0,200);
        update_option(self::LOG,$log,false);
        return $row;
    }

    public function render(){
        if (!current_user_can('manage_options')) return;
        $o = get_option(self::OPTS, []);
        $o = wp_parse_args($o, [
            'api_key'=>'','hmac_secret'=>'','require_signature'=>true,'max_skew'=>300,
            'allow_ips'=>'','allow_hosts'=>'','enable_proxy_install'=>true,'mm_api_key_override'=>''
        ]);
        $log = get_option(self::LOG, []);
        ?>
        <div class="wrap">
            <h1>WTP Agent Bridge (Enterprise)</h1>
            <p>Dwupoziomowe uwierzytelnianie: <strong>X-WTP-Key</strong> + <strong>X-WTP-Signature</strong> (HMAC-SHA256) + znacznik czasu <strong>X-WTP-Timestamp</strong>.</p>
            <form method="post" action="options.php">
                <?php settings_fields(self::SLUG); ?>
                <table class="form-table">
                    <tr><th>API Key</th><td><input type="text" name="<?php echo self::OPTS; ?>[api_key]" value="<?php echo esc_attr($o['api_key']);?>" class="regular-text" style="width:420px;"></td></tr>
                    <tr><th>HMAC Secret</th><td><input type="text" name="<?php echo self::OPTS; ?>[hmac_secret]" value="<?php echo esc_attr($o['hmac_secret']);?>" class="regular-text" style="width:420px;"></td></tr>
                    <tr><th>Wymagaj podpisu</th><td><label><input type="checkbox" name="<?php echo self::OPTS; ?>[require_signature]" <?php checked(!empty($o['require_signature']));?>> Tak</label></td></tr>
                    <tr><th>Maks. odchylenie czasu</th><td><input type="number" name="<?php echo self::OPTS; ?>[max_skew]" value="<?php echo esc_attr(intval($o['max_skew']));?>" min="0" step="1"> sek.</td></tr>
                    <tr><th>Dozwolone IP (opcjonalnie)</th><td><textarea name="<?php echo self::OPTS; ?>[allow_ips]" rows="3" cols="60"><?php echo esc_textarea($o['allow_ips']);?></textarea></td></tr>
                    <tr><th>Dozwolone hosty ZIP (opcjonalnie)</th><td><textarea name="<?php echo self::OPTS; ?>[allow_hosts]" rows="3" cols="60"><?php echo esc_textarea($o['allow_hosts']);?></textarea></td></tr>
                    <tr><th>Proxy instalacji ZIP</th><td><label><input type="checkbox" name="<?php echo self::OPTS; ?>[enable_proxy_install]" <?php checked(!empty($o['enable_proxy_install']));?>> Włączone</label></td></tr>
                    <tr><th>Module Manager API Key (override)</th><td><input type="text" name="<?php echo self::OPTS; ?>[mm_api_key_override]" value="<?php echo esc_attr($o['mm_api_key_override']);?>" class="regular-text" style="width:420px;"><p class="description">Jeśli w Twoim Module Managerze klucz jest przechowywany pod inną opcją/nazwą – wklej go tutaj. Bridge użyje tej wartości zamiast szukać automatycznie.</p></td></tr>
                </table>
                <p><button class="button button-primary">Zapisz</button></p>
            </form>

            <h2>Endpointy</h2>
            <ul>
                <li><code>GET <?php echo esc_html( get_rest_url(null, '/wtp/v1/agent/ping') ); ?></code></li>
                <li><code>GET <?php echo esc_html( get_rest_url(null, '/wtp/v1/agent/health') ); ?></code></li>
                <li><code>GET <?php echo esc_html( get_rest_url(null, '/wtp/v1/agent/autofixer-log') ); ?></code></li>
                <li><code>POST <?php echo esc_html( get_rest_url(null, '/wtp/v1/agent/install') ); ?></code> — body: {"url":"https://…/plugin.zip"}</li>
            </ul>

            <h2>Log mostka</h2>
            <?php if ($log): ?>
                <table class="widefat striped">
                    <thead><tr><th>Czas (UTC)</th><th>Akcja</th><th>Wynik</th><th>Szczegóły</th></tr></thead>
                    <tbody>
                    <?php foreach ($log as $row): ?>
                        <tr>
                            <td><?php echo esc_html($row['time']);?></td>
                            <td><?php echo esc_html($row['action']);?></td>
                            <td><?php echo esc_html($row['result']);?></td>
                            <td><?php echo esc_html(is_string($row['details'])?$row['details']:wp_json_encode($row['details'], JSON_UNESCAPED_SLASHES));?></td>
                        </tr>
                    <?php endforeach; ?>
                    </tbody>
                </table>
            <?php else: ?>
                <p>Brak wpisów.</p>
            <?php endif; ?>
        </div>
        <?php
    }

    private function check_auth(){
        $o = get_option(self::OPTS, []);
        $o = wp_parse_args($o, ['api_key'=>'','hmac_secret'=>'','require_signature'=>true,'max_skew'=>300,'allow_ips'=>'']);
        $key = isset($_SERVER['HTTP_X_WTP_KEY']) ? sanitize_text_field($_SERVER['HTTP_X_WTP_KEY']) : '';
        if ( empty($o['api_key']) || ! hash_equals($o['api_key'], $key) ){
            return new \WP_REST_Response(['ok'=>false,'error'=>'unauthorized'], 401);
        }

        $ips = array_filter(array_map('trim', preg_split('/\r\n|\r|\n/', isset($o['allow_ips'])?$o['allow_ips']:'' )));
        if ($ips){
            $remote = isset($_SERVER['REMOTE_ADDR']) ? $_SERVER['REMOTE_ADDR'] : '';
            if ($remote && !in_array($remote, $ips, true)){
                return new \WP_REST_Response(['ok'=>false,'error'=>'ip_not_allowed'], 403);
            }
        }

        if (!empty($o['require_signature'])){
            $ts = isset($_SERVER['HTTP_X_WTP_TIMESTAMP']) ? intval($_SERVER['HTTP_X_WTP_TIMESTAMP']) : 0;
            $sig = isset($_SERVER['HTTP_X_WTP_SIGNATURE']) ? sanitize_text_field($_SERVER['HTTP_X_WTP_SIGNATURE']) : '';
            if (!$ts || !$sig){
                return new \WP_REST_Response(['ok'=>false,'error'=>'signature_required'], 401);
            }
            $skew = intval($o['max_skew']);
            if ($skew > 0 && abs(time() - $ts) > $skew){
                return new \WP_REST_Response(['ok'=>false,'error'=>'timestamp_out_of_range'], 401);
            }
            $method = isset($_SERVER['REQUEST_METHOD']) ? $_SERVER['REQUEST_METHOD'] : 'GET';
            $path = isset($_SERVER['REQUEST_URI']) ? parse_url($_SERVER['REQUEST_URI'], PHP_URL_PATH) : '/';
            $raw = file_get_contents('php://input');
            $canonical = $ts . "\n" . $method . "\n" . $path . "\n" . $raw;
            $expected = hash_hmac('sha256', $canonical, (string)$o['hmac_secret']);
            if (!hash_equals($expected, $sig)){
                return new \WP_REST_Response(['ok'=>false,'error'=>'bad_signature'], 401);
            }
        }
        return true;
    }

    public function rest(){
        register_rest_route('wtp/v1', '/agent/ping', [
            'methods' => 'GET',
            'permission_callback' => '__return_true',
            'callback' => function(){
                $auth = $this->check_auth();
                if ($auth !== true) return $auth;
                return new \WP_REST_Response(['ok'=>true,'time'=>gmdate('c'),'site'=>home_url('/')], 200);
            }
        ]);

        register_rest_route('wtp/v1', '/agent/health', [
            'methods' => 'GET',
            'permission_callback' => '__return_true',
            'callback' => function(){
                $auth = $this->check_auth();
                if ($auth !== true) return $auth;
                if ( ! function_exists('rest_do_request') ) return new \WP_REST_Response(['ok'=>false,'error'=>'no_rest'], 500);
                $req = new \WP_REST_Request('GET','/wtp/v1/health');
                $resp = rest_do_request($req);
                if ($resp instanceof \WP_REST_Response){
                    $data = $resp->get_data();
                    return new \WP_REST_Response(['ok'=>true,'data'=>$data], 200);
                }
                return new \WP_REST_Response(['ok'=>false,'error'=>'health_unavailable'], 404);
            }
        ]);

        register_rest_route('wtp/v1', '/agent/autofixer-log', [
            'methods' => 'GET',
            'permission_callback' => '__return_true',
            'callback' => function(){
                $auth = $this->check_auth();
                if ($auth !== true) return $auth;
                $log = get_option('wtp_autofixer_log', []);
                return new \WP_REST_Response(['ok'=>true,'data'=>is_array($log)?$log:[]], 200);
            }
        ]);

        register_rest_route('wtp/v1', '/agent/install', [
            'methods' => 'POST',
            'permission_callback' => '__return_true',
            'callback' => function(\WP_REST_Request $req){
                $auth = $this->check_auth();
                if ($auth !== true) return $auth;

                $o = get_option(self::OPTS, []);
                $o = wp_parse_args($o, ['allow_hosts'=>'','enable_proxy_install'=>true,'mm_api_key_override'=>'']);
                if (empty($o['enable_proxy_install'])) return new \WP_REST_Response(['ok'=>false,'error'=>'install_proxy_disabled'], 403);

                $url = esc_url_raw( $req->get_param('url') );
                if (!$url) return new \WP_REST_Response(['ok'=>false,'error'=>'missing url'], 400);

                // host whitelist
                $hosts = array_filter(array_map('trim', preg_split('/\r\n|\r|\n/', isset($o['allow_hosts'])?$o['allow_hosts']:'' )));
                if ($hosts){
                    $h = parse_url($url, PHP_URL_HOST);
                    if (!$h || !in_array($h, $hosts, true)) return new \WP_REST_Response(['ok'=>false,'error'=>'host not allowed'], 403);
                }

                // Module Manager API key
                $mm_key = trim((string)$o['mm_api_key_override']);
                if (!$mm_key){
                    $mm = get_option('wtp_module_manager_opts', []);
                    if (is_array($mm) && isset($mm['api_key'])) $mm_key = (string)$mm['api_key'];
                }
                if (!$mm_key){
                    $this->log('install','fail','module_manager_missing_or_no_key');
                    return new \WP_REST_Response(['ok'=>false,'error'=>'module_manager_missing_or_no_key'], 500);
                }

                $endpoint = get_rest_url(null, '/wtp/v1/mods/install');

                // pomocnicza funkcja wywołania MM
                $call_mm = function(array $payload) use ($endpoint, $mm_key){
                    $res = wp_remote_post( $endpoint, [
                        'timeout' => 150,
                        'headers' => [
                            'X-WTP-Key'   => $mm_key,
                            'Content-Type'=> 'application/json',
                            'Accept'      => 'application/json',
                        ],
                        'body'    => wp_json_encode($payload),
                    ]);
                    $code = is_wp_error($res) ? 0 : wp_remote_retrieve_response_code($res);
                    $body_raw = is_wp_error($res) ? $res->get_error_message() : wp_remote_retrieve_body($res);
                    $body = json_decode($body_raw, true);
                    return [$code, $body, $body_raw];
                };

                // 1) standardowa próba
                list($code, $body, $raw) = $call_mm(['url'=>$url]);

                // 2) retry z overwrite/force jeśli MM zgłasza, że katalog istnieje
                $need_overwrite = false;
                if ($code !== 200) {
                    $msg = '';
                    if (is_array($body)) {
                        $msg = strtolower( (string)($body['msg'] ?? $body['error'] ?? $body['message'] ?? '') );
                    } else {
                        $msg = strtolower(substr($raw,0,300));
                    }
                    if (strpos($msg,'destination folder') !== false || strpos($msg,'folder exists') !== false) {
                        $need_overwrite = true;
                    }
                }
                if ($need_overwrite) {
                    list($code, $body, $raw) = $call_mm(['url'=>$url,'overwrite'=>true,'force'=>true]);
                }

                if ($code !== 200){
                    $snippet = is_string($raw) ? substr($raw,0,300) : '';
                    $this->log('install','fail','mm_http_'.$code.' :: '.$snippet);
                    return new \WP_REST_Response([
                        'ok'=>false,
                        'error'=>'module_manager_http_'.$code,
                        'reason'=> (is_array($body) ? ($body['msg'] ?? $body['error'] ?? null) : null),
                        'body'=> $body ?: $snippet
                    ], 500);
                }

                $this->log('install','ok', isset($body['installed'])?$body['installed']:'unknown');
                return new \WP_REST_Response(['ok'=>true,'module_manager'=>$body], 200);
            }
        ]);
    }
}

new WTP_Agent_Bridge_Ent();