<?php
/*
Plugin Name: WTP Site Snapshot
Description: Tworzy snapshot podstawowych danych o stronie (WP, PHP, motyw, wtyczki).
Version: 0.1.0
Author: WeekTopPick Autopilot
*/
if (!defined('ABSPATH')) exit;

add_action('admin_menu', function(){
    add_menu_page('WTP Snapshot', 'WTP Snapshot', 'manage_options', 'wtp-snapshot', function(){
        echo '<div class="wrap"><h1>WTP Site Snapshot</h1>';
        echo '<p>WordPress: '.get_bloginfo('version').'</p>';
        echo '<p>PHP: '.phpversion().'</p>';
        echo '<p>Motyw: '.wp_get_theme()->get("Name").' '.wp_get_theme()->get("Version").'</p>';
        echo '<h2>Wtyczki</h2><ul>';
        foreach (get_plugins() as $slug=>$plugin){
            echo '<li>'.$plugin['Name'].' '.$plugin['Version'].'</li>';
        }
        echo '</ul></div>';
    });
});
