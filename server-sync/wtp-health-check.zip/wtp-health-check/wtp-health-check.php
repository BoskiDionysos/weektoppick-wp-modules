<?php
/**
 * Plugin Name: WTP Health Check
 * Description: Autopilot with JSON export, history (10), hourly cron. Agent-ready with run_id, duration_ms, risk_score, thresholds, violations + PUSH webhook to Make.
 * Version: 2.6.0
 * Author: WeekTopPick Autopilot
 * License: GPLv2 or later
 */

if ( ! defined( 'ABSPATH' ) ) exit;

class WTP_Health_Check {
    const SLUG         = 'wtp-health-check';
    const CAP          = 'manage_options';
    const REST_NS      = 'wtp/v1';
    const REST_HEALTH  = '/health';
    const REST_HISTORY = '/health-history';
    const CRON_HOOK    = 'wtp_health_watchdog_event';
    const OPTION_KEY   = 'wtp_health_history';
    const OPTS_KEY     = 'wtp_health_opts';
    const BUILD        = '2.6.0';

    public function __construct() {
        add_action('admin_menu', [$this, 'admin_menu']);
        add_action('admin_enqueue_scripts', [$this, 'enqueue']);
        add_action('rest_api_init', [$this, 'register_rest']);
        register_activation_hook(__FILE__, [$this, 'on_activate']);
        register_deactivation_hook(__FILE__, [$this, 'on_deactivate']);
        add_action(self::CRON_HOOK, [$this, 'cron_watchdog']);
    }

    public function on_activate() {
        if ( ! wp_next_scheduled(self::CRON_HOOK) ) {
            wp_schedule_event(time() + 300, 'hourly', self::CRON_HOOK);
        }
        // default options
        $opts = get_option(self::OPTS_KEY, []);
        if (!is_array($opts)) $opts=[];
        $defaults = ['webhook_url'=>'','webhook_secret'=>'','webhook_enabled'=>false,'push_on_cron'=>true,'push_on_manual'=>true];
        update_option(self::OPTS_KEY, array_merge($defaults, $opts), false);
    }

    public function on_deactivate() {
        $ts = wp_next_scheduled(self::CRON_HOOK);
        if ($ts) wp_unschedule_event($ts, self::CRON_HOOK);
    }

    public function admin_menu() {
        add_menu_page('WTP Health Check','WTP Health Check', self::CAP, self::SLUG, [$this, 'render_page'],'dashicons-heart',55);
        add_submenu_page(self::SLUG, 'Ustawienia webhook', 'Ustawienia', self::CAP, self::SLUG.'-settings', [$this,'render_settings']);
    }

    public function enqueue($hook) {
        if ($hook !== 'toplevel_page_' . self::SLUG) return;
        $ver = self::BUILD;
        wp_enqueue_style(self::SLUG, plugins_url('admin.css', __FILE__), [], $ver);
        wp_enqueue_script(self::SLUG, plugins_url('admin.js', __FILE__), ['wp-api-fetch'], $ver, true);
        wp_localize_script(self::SLUG, 'WTPHealth', [
            'restHealth'  => esc_url_raw( rest_url( self::REST_NS . self::REST_HEALTH ) ),
            'restHistory' => esc_url_raw( rest_url( self::REST_NS . self::REST_HISTORY ) ),
            'nonce'       => wp_create_nonce('wp_rest'),
            'home'        => home_url('/'),
            'build'       => $ver,
        ]);
    }

    public function render_page() { ?>
        <div class="wrap wtp-health">
            <h1>WTP Health Check <small class="build">build <?php echo esc_html(self::BUILD); ?></small></h1>
            <p class="desc">Autopilot: Core + Plugins + LOCKS + System. URL diagnostics optional. JSON export + history. Agent‑ready + PUSH webhook.</p>

            <div class="panel">
                <a href="<?php echo admin_url('admin.php?page='.self::SLUG.'-settings');?>" class="button">Ustawienia</a>
                <button id="wtp-run" class="button button-primary">Uruchom testy</button>
                <button id="wtp-json" class="button">Download JSON</button>
                <span id="wtp-status" class="status"></span>
                <div id="wtp-summary" class="summary"></div>
            </div>

            <div id="wtp-sections" class="sections hidden">
                <h2>Core</h2><table class="widefat fixed striped"><tbody id="wtp-core"></tbody></table>
                <h2>Wtyczki / Motyw</h2><table class="widefat fixed striped"><tbody id="wtp-plugins"></tbody></table>
                <h2>LOCKS</h2><table class="widefat fixed striped"><tbody id="wtp-locks"></tbody></table>
                <h2>System</h2><table class="widefat fixed striped"><tbody id="wtp-system"></tbody></table>
                <h2>Diagnostyka URL (opcjonalna)</h2>
                <div id="wtp-url-note">Sekcja działa tylko jeśli aktywna jest wtyczka WTP URL Tester.</div>
                <table class="widefat fixed striped"><thead><tr>
                    <th>URL</th><th>Status</th><th>Czas (ms)</th><th>Uwagi</th></tr></thead>
                    <tbody id="wtp-urls"></tbody>
                </table>
                <h2>Historia (ostatnie 10)</h2>
                <table class="widefat fixed striped"><thead><tr><th>Czas</th><th>Status</th><th>Risk</th><th>Uwagi</th></tr></thead><tbody id="wtp-history"></tbody></table>
            </div>

            <p class="help">Watchdog: co godzinę sprawdza <code>/</code> i <code>/robots.txt</code>. Jeśli ≠200 → e‑mail do administratora.</p>
        </div>
    <?php }

    public function render_settings(){
        if (!current_user_can(self::CAP)) return;
        $opts = get_option(self::OPTS_KEY, []);
        if ($_SERVER['REQUEST_METHOD']==='POST' && check_admin_referer('wtp_health_opts')){
            $opts['webhook_url']   = esc_url_raw($_POST['webhook_url'] ?? '');
            $opts['webhook_secret']= sanitize_text_field($_POST['webhook_secret'] ?? '');
            $opts['webhook_enabled']= isset($_POST['webhook_enabled']);
            $opts['push_on_cron']   = isset($_POST['push_on_cron']);
            $opts['push_on_manual'] = isset($_POST['push_on_manual']);
            update_option(self::OPTS_KEY,$opts,false);
            echo '<div class="updated notice"><p>Zapisano ustawienia.</p></div>';
        }
        ?>
        <div class="wrap">
            <h1>WTP Health – Ustawienia webhook (PUSH do Make)</h1>
            <form method="post">
                <?php wp_nonce_field('wtp_health_opts'); ?>
                <table class="form-table">
                    <tr><th scope="row">Webhook URL (Make.com → Webhooks → Custom webhook)</th>
                        <td><input type="url" name="webhook_url" value="<?php echo esc_attr($opts['webhook_url'] ?? '');?>" class="regular-text" style="width: 60%;">
                            <p class="description">Np. https://hook.eu1.make.com/XXXXXXXX</p></td></tr>
                    <tr><th scope="row">Sekret (opcjonalny HMAC-SHA256)</th>
                        <td><input type="text" name="webhook_secret" value="<?php echo esc_attr($opts['webhook_secret'] ?? '');?>" class="regular-text">
                            <p class="description">Jeśli ustawisz, do żądania dodamy nagłówek X-WTP-Signature.</p></td></tr>
                    <tr><th scope="row">Wysyłka PUSH</th>
                        <td>
                            <label><input type="checkbox" name="webhook_enabled" <?php checked(!empty($opts['webhook_enabled']));?>> Aktywne</label><br>
                            <label><input type="checkbox" name="push_on_manual" <?php checked(!empty($opts['push_on_manual']));?>> Wysyłaj po ręcznym teście</label><br>
                            <label><input type="checkbox" name="push_on_cron" <?php checked(!empty($opts['push_on_cron']));?>> Wysyłaj po cronie (co godzinę)</label>
                        </td></tr>
                </table>
                <p><button class="button button-primary">Zapisz</button></p>
            </form>
        </div>
        <?php
    }

    public function register_rest() {
        register_rest_route(self::REST_NS, self::REST_HEALTH, [
            'methods'  => ['POST','GET'],
            'callback' => [$this, 'rest_run_health'],
            'permission_callback' => function() { return current_user_can(self::CAP); }
        ]);
        register_rest_route(self::REST_NS, self::REST_HISTORY, [
            'methods'  => 'GET',
            'callback' => [$this, 'rest_history'],
            'permission_callback' => function() { return current_user_can(self::CAP); }
        ]);
    }

    private function thresholds() {
        return ['home_max_ms'=>1000,'robots_max_ms'=>1000];
    }

    private function core_checks() {
        $rows=[];
        try {
            $rest_root = rest_url();
            $rows[]=['name'=>'REST API dostępne','ok'=>!empty($rest_root),'note'=>$rest_root];

            $uploads = wp_get_upload_dir();
            $writable=false; $note=$uploads['basedir'];
            if ( function_exists('wp_is_writable_path') ) {
                $writable = wp_is_writable_path($uploads['basedir']);
            } else {
                $writable = is_writable($uploads['basedir']);
                $note .= ' (fallback)';
            }
            $rows[]=['name'=>'Katalog uploadów zapisywalny','ok'=>$writable,'note'=>$note];

            $permalinks = get_option('permalink_structure') ? 'pretty' : 'plain';
            $rows[]=['name'=>'Permalinki','ok'=>true,'note'=>$permalinks];

            $tz = get_option('timezone_string') ?: 'UTC';
            $rows[]=['name'=>'Strefa czasowa','ok'=>true,'note'=>$tz];
        } catch (\Throwable $e) {
            $rows[]=['name'=>'Core check error','ok'=>false,'note'=>$e->getMessage()];
        }
        return $rows;
    }

    private function plugins_checks() {
        $rows=[];
        try {
            $active = (array) get_option('active_plugins', []);
            $count = count($active);
            $theme = wp_get_theme();
            $rows[]=['name'=>'Aktywne wtyczki','ok'=>true,'note'=> (string)$count];
            $rows[]=['name'=>'Motyw','ok'=>true,'note'=> $theme->get('Name').' '.$theme->get('Version')];
        } catch (\Throwable $e) {
            $rows[]=['name'=>'Plugins check error','ok'=>false,'note'=>$e->getMessage()];
        }
        return $rows;
    }

    private function locks_checks() {
        $rows=[];
        try {
            $multilang_on = false; $seo_sitemaps = false;
            $rows[]=['name'=>'Multilang Core','ok'=>$multilang_on,'note'=>$multilang_on?'ON':'OFF (plan)'];
            $rows[]=['name'=>'SEO Sitemaps','ok'=>$seo_sitemaps,'note'=>$seo_sitemaps?'ON':'OFF (plan)'];
        } catch (\Throwable $e) {
            $rows[]=['name'=>'Locks check error','ok'=>false,'note'=>$e->getMessage()];
        }
        return $rows;
    }

    private function system_snapshot() {
        $rows=[];
        try {
            global $wpdb;
            $rows=[
                'wp_version'=> get_bloginfo('version'),
                'php_version'=> PHP_VERSION,
                'theme'=> wp_get_theme()->get('Name') . ' ' . wp_get_theme()->get('Version'),
                'home_url'=> home_url('/'),
                'site_url'=> site_url('/'),
                'memory_limit'=> defined('WP_MEMORY_LIMIT')?WP_MEMORY_LIMIT:'',
                'debug'=> (defined('WP_DEBUG') && WP_DEBUG) ? 'on' : 'off',
                'db_server'=> method_exists($wpdb,'db_version')? $wpdb->db_version() : ''
            ];
        } catch (\Throwable $e) {
            $rows=['system_error'=>$e->getMessage()];
        }
        return $rows;
    }

    private function call_url_tester_safe($urls) {
        try {
            if ( ! function_exists('rest_do_request') ) return ['error'=>'REST dispatch not available'];
            $request = new \WP_REST_Request('POST', '/wtp/v1/urltester');
            $request->set_param('urls', array_values($urls));
            $response = rest_do_request($request);
            $code = $response->get_status();
            if ($code !== 200) return ['error'=>'URL Tester returned '.$code];
            return $response->get_data();
        } catch (\Throwable $e) {
            return ['error'=>$e->getMessage()];
        }
    }

    private function evaluate_urls($results, $th) {
        $eval = []; $viol=[];
        foreach ($results as $r) {
            $path = parse_url($r['final_url'], PHP_URL_PATH) ?? '';
            $status = intval($r['status']); $time = intval($r['time_ms']);
            $ok=false; $note='';
            if ($path==='/'||$path===''){
                $ok=($status===200&&$time<$th['home_max_ms']); $note=$ok?'OK':('Wymagane 200 i <'.$th['home_max_ms'].'ms');
                if (!$ok) $viol[]=['url'=>$r['final_url'],'expect'=>'200 & <'.$th['home_max_ms'].'ms','got'=>"$status/$time"];
            } elseif($path==='/robots.txt'){
                $ok=($status===200&&$time<$th['robots_max_ms']); $note=$ok?'OK':('Wymagane 200 i <'.$th['robots_max_ms'].'ms');
                if (!$ok) $viol[]=['url'=>$r['final_url'],'expect'=>'200 & <'.$th['robots_max_ms'].'ms','got'=>"$status/$time"];
            } elseif($path==='/pl/'){
                $ok=($status===404); $note=$ok?'404 oczekiwane (Multilang OFF)':'Oczekiwane 404 (Multilang OFF)';
                if (!$ok) $viol[]=['url'=>$r['final_url'],'expect'=>'404','got'=>"$status"];
            } elseif($path==='/sitemap_index.xml'){
                $ok=($status===404); $note=$ok?'404 oczekiwane (SEO OFF)':'Oczekiwane 404 (SEO OFF)';
                if (!$ok) $viol[]=['url'=>$r['final_url'],'expect'=>'404','got'=>"$status"];
            } else {
                $ok=($status===200); $note=$ok?'OK':'Wymagane 200';
                if (!$ok) $viol[]=['url'=>$r['final_url'],'expect'=>'200','got'=>"$status"];
            }
            $eval[]=['url'=>$r['final_url'],'status'=>$status,'time_ms'=>$time,'ok'=>$ok,'note'=>$note];
        }
        return [$eval,$viol];
    }

    private function calc_risk_score($data) {
        $score = 100;
        foreach (['core','plugins','locks'] as $sec) {
            foreach ($data[$sec] as $row) { if (empty($row['ok'])) { $score -= 10; } }
        }
        foreach ($data['urls'] as $u) { if (empty($u['ok'])) { $score -= 10; } }
        if ($score < 0) $score = 0;
        return $score;
    }

    private function load_opts(){ $o=get_option(self::OPTS_KEY,[]); return is_array($o)?$o:[]; }
    private function load_history(){ $h=get_option(self::OPTION_KEY,[]); return is_array($h)?$h:[]; }
    private function save_history($entry){
        $history=$this->load_history();
        array_unshift($history,$entry);
        $history=array_slice($history,0,10);
        update_option(self::OPTION_KEY,$history,false);
        return $history;
    }

    private function push_webhook($payload,$reason='manual'){
        $opts=$this->load_opts();
        if(empty($opts['webhook_enabled']) || empty($opts['webhook_url'])) return false;
        $args=['body'=>wp_json_encode($payload),'headers'=>['Content-Type'=>'application/json','X-WTP-Reason'=>$reason],'timeout'=>10];
        if(!empty($opts['webhook_secret'])){
            $sig=hash_hmac('sha256',$args['body'],$opts['webhook_secret']);
            $args['headers']['X-WTP-Signature']=$sig;
        }
        $resp=wp_remote_post($opts['webhook_url'],$args);
        return !is_wp_error($resp) ? wp_remote_retrieve_response_code($resp) : false;
    }

    public function rest_run_health(\WP_REST_Request $req) {
        $start = microtime(true);
        $run_id = wp_generate_uuid4();
        $th = $this->thresholds();

        $data=[
            'run_id'=> $run_id,
            'generated_at'=>gmdate('c'),
            'site'=>home_url('/'),
            'build'=> self::BUILD,
            'thresholds'=> $th,
            'core'=>$this->core_checks(),
            'plugins'=>$this->plugins_checks(),
            'locks'=>$this->locks_checks(),
            'system'=>$this->system_snapshot(),
            'urls'=>[],
            'violations'=>[],
            'url_note'=>'Brak wyników – wtyczka URL Tester nieaktywna',
            'ok'=>true
        ];
        try {
            $tester=$this->call_url_tester_safe(['/', '/pl/', '/sitemap_index.xml', '/robots.txt']);
            if(isset($tester['results'])){
                list($urls,$viol)=$this->evaluate_urls($tester['results'],$th);
                $data['urls']=$urls; $data['violations']=array_merge($data['violations'],$viol);
                $data['url_note']='Dane z WTP URL Tester';
            } elseif(isset($tester['error'])){
                $data['url_note']='⚠️ '.$tester['error'];
            }
        } catch (\Throwable $e) {
            $data['url_note']='⚠️ Exception: '.$e->getMessage();
        }
        $data['risk_score']=$this->calc_risk_score($data);
        $data['duration_ms']= intval( (microtime(true)-$start)*1000 );

        $entry=[ 'time'=>$data['generated_at'],'run_id'=>$run_id,'ok'=>$data['ok'],'risk'=>$data['risk_score'],'note'=>$data['url_note'] ];
        $history=$this->save_history($entry);
        $data['history']=$history;

        // PUSH (manual trigger)
        $o=$this->load_opts();
        if(!empty($o['push_on_manual'])){ $this->push_webhook($data,'manual'); }

        return $data;
    }

    public function rest_history(\WP_REST_Request $req){ return $this->load_history(); }

    public function cron_watchdog() {
        $tester=$this->call_url_tester_safe(['/', '/robots.txt']);
        $bad=[];
        if(isset($tester['results'])){
            foreach($tester['results'] as $r){
                $path=parse_url($r['final_url'],PHP_URL_PATH)??'';
                $status=intval($r['status']);
                if(($path==='/'||$path==='/robots.txt')&&$status!==200){ $bad[]=$path.' status='.$status; }
            }
        }
        if($bad){
            $to=get_option('admin_email');
            $subj='WTP Watchdog alert: '.get_bloginfo('name');
            $msg="Watchdog problem:\n".implode("\n",$bad)."\nSite: ".home_url('/')."\nTime: ".gmdate('c');
            wp_mail($to,$subj,$msg);
        }
        $entry=[ 'time'=>gmdate('c'), 'run_id'=>wp_generate_uuid4(), 'ok'=>empty($bad), 'risk'=> empty($bad)?100:70, 'note'=> empty($bad)?'watchdog ok':'watchdog: '.implode(', ',$bad) ];
        $this->save_history($entry);

        // Build minimal payload for PUSH on cron
        $payload=[
            'run_id'=>$entry['run_id'],
            'generated_at'=>$entry['time'],
            'site'=>home_url('/'),
            'build'=> self::BUILD,
            'watchdog'=> true,
            'ok'=> $entry['ok'],
            'risk_score'=> $entry['risk'],
            'violations'=> $bad,
        ];
        $o=$this->load_opts();
        if(!empty($o['push_on_cron'])){ $this->push_webhook($payload,'cron'); }
    }
}
new WTP_Health_Check();
