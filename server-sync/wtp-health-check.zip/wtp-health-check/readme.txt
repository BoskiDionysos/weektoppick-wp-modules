WTP Health Check v2.6.0
========================
NOWOŚĆ: PUSH do Make.com
- Ustawienia → wpisz Webhook URL, opcjonalny sekret (HMAC)
- Włącz „Aktywne” + zaznacz kiedy wysyłać: po teście i/lub po cronie
- Wysyłamy JSON pełnego raportu (manual) lub heartbeat (cron)

W JSON nadal: run_id, generated_at, build, duration_ms, risk_score, thresholds, violations, core/plugins/locks/system, urls, history.
