(function(){
  const $=(s)=>document.querySelector(s);
  function setStatus(m){$('#wtp-status').textContent=m||'';}
  async function callHealth(method='POST'){
    const opt={method,headers:{'X-WP-Nonce':WTPHealth.nonce}};
    if(method==='POST'){opt.headers['Content-Type']='application/json'; opt.body='{}';}
    const res=await fetch(WTPHealth.restHealth,opt);
    if(!res.ok){throw new Error('REST '+res.status+': '+await res.text());}
    return res.json();
  }
  async function getHistory(){
    const res=await fetch(WTPHealth.restHistory,{headers:{'X-WP-Nonce':WTPHealth.nonce}});
    if(!res.ok){throw new Error('REST '+res.status+': '+await res.text());}
    return res.json();
  }
  function row(k,v,isOk=true){const tr=document.createElement('tr');tr.innerHTML=`<th>${esc(k)}</th><td class="${isOk?'ok':'fail'}">${esc(v||'')}</td>`;return tr;}
  function render(res){
    const sum=$('#wtp-summary');sum.classList.remove('bad');sum.style.display='block';
    sum.textContent=`Diagnoza wykonana. Build: ${esc(res.build||'')} · run_id: ${esc(res.run_id)} · ${res.duration_ms||0} ms · risk ${res.risk_score}`;
    const tbodyC=$('#wtp-core');tbodyC.innerHTML='';(res.core||[]).forEach(c=>tbodyC.appendChild(row(c.name,c.note,c.ok)));
    const tbodyP=$('#wtp-plugins');tbodyP.innerHTML='';(res.plugins||[]).forEach(p=>tbodyP.appendChild(row(p.name,p.note,p.ok)));
    const tbodyL=$('#wtp-locks');tbodyL.innerHTML='';(res.locks||[]).forEach(l=>tbodyL.appendChild(row(l.name,l.note,l.ok)));
    const sys=$('#wtp-system');sys.innerHTML='';Object.keys(res.system||{}).forEach(k=>sys.appendChild(row(k,res.system[k],true)));
    const tbodyU=$('#wtp-urls');tbodyU.innerHTML='';(res.urls||[]).forEach(u=>{
      const tr=document.createElement('tr');tr.innerHTML=`<td><code>${esc(u.url)}</code></td><td class="${u.ok?'ok':'fail'}">${u.status}</td><td>${u.time_ms??''}</td><td>${esc(u.note||'')}</td>`;tbodyU.appendChild(tr);});
    if(res.url_note)$('#wtp-url-note').textContent=res.url_note;
    $('#wtp-sections').classList.remove('hidden');
    if(res.history){paintHistory(res.history);} else {loadHistory();}
  }
  function paintHistory(hist){
    const tbody=$('#wtp-history');tbody.innerHTML='';
    (hist||[]).forEach(h=>{
      const tr=document.createElement('tr');
      tr.innerHTML=`<td>${esc(h.time)}</td><td class="${h.ok?'ok':'fail'}">${h.ok?'OK':'Fail'}</td><td>${esc(h.risk)}</td><td>${esc(h.note||'')}</td>`;
      tbody.appendChild(tr);
    });
  }
  async function loadHistory(){
    try{paintHistory(await getHistory());}catch(e){console.error(e);}
  }
  function esc(s){return String(s||'').replace(/[&<>"']/g,m=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;'}[m]));}
  async function run(){setStatus('Uruchamiam…');try{const data=await callHealth('POST');render(data);setStatus('Gotowe.');}catch(e){alert(e.message||e);setStatus('Błąd.');}}
  async function downloadJson(){
    try{
      const data=await callHealth('GET');
      const blob=new Blob([JSON.stringify(data,null,2)],{type:'application/json;charset=utf-8'});
      const url=URL.createObjectURL(blob);
      const a=document.createElement('a');a.href=url;a.download='wtp-health-'+Date.now()+'.json';a.click();URL.revokeObjectURL(url);
      if(data.history){paintHistory(data.history);} else {loadHistory();}
    }catch(e){alert(e.message||e);}
  }
  document.addEventListener('DOMContentLoaded',()=>{
    $('#wtp-run').addEventListener('click',run);
    $('#wtp-json').addEventListener('click',downloadJson);
    loadHistory();
  });
})();