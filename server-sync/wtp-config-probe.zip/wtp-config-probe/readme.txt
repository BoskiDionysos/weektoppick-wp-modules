WTP Config Probe – safe wp-config lines, .htaccess sections, redirect tests.
