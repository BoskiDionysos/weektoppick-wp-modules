<?php
/**
 * Plugin Name: WTP Config Probe
 * Description: Podgląd bezpiecznych linii wp-config.php i sekcji .htaccess (WP + nasze reguły) + test przykładowych redirectów.
 * Version: 1.0.0
 * Author: WeekTopPick
 * License: GPLv2 or later
 */
if ( ! defined('ABSPATH') ) exit;

add_action('admin_menu', function(){
    add_menu_page('WTP Config Probe','WTP Config','manage_options','wtp-config-probe','wtp_config_page','dashicons-admin-tools',61);
});

function wtp_safe_wp_config_lines(){
    $file = ABSPATH . 'wp-config.php';
    if ( ! file_exists($file) ) return ['error'=>'wp-config.php not found'];
    $lines = @file($file, FILE_IGNORE_NEW_LINES);
    if ( ! $lines ) return ['error'=>'cannot read wp-config.php'];
    $allowed = ['WP_ENV','WP_DEBUG','WP_DEBUG_LOG','SAVEQUERIES','DISABLE_WP_CRON','WP_MEMORY_LIMIT','WP_MAX_MEMORY_LIMIT'];
    $out = [];
    foreach($lines as $ln){
        if ( preg_match('/define\(\s*\'(.*?)\'\s*,\s*(.*?)\)/', $ln, $m) ) {
            $const = $m[1];
            if ( in_array($const, $allowed, true) ) $out[] = trim($ln);
        }
    }
    return $out;
}

function wtp_htaccess_sections(){
    $file = ABSPATH . '.htaccess';
    if ( ! file_exists($file) ) return ['error'=>'.htaccess not found'];
    $txt = @file_get_contents($file);
    if ( $txt === false ) return ['error'=>'cannot read .htaccess'];
    $blocks = [];
    if ( preg_match('/# BEGIN WordPress[\s\S]*?# END WordPress/', $txt, $m) ) $blocks['wordpress'] = $m[0];
    if ( preg_match('/# BEGIN WTP[\s\S]*?# END WTP/', $txt, $m) ) $blocks['wtp'] = $m[0];
    return $blocks ?: ['info'=>'no known sections found'];
}

function wtp_test_redirects($samples){
    $res = [];
    foreach($samples as $path){
        $url = home_url($path);
        $r = wp_remote_get($url, ['timeout'=>8, 'redirection'=>10]);
        if ( is_wp_error($r) ) { $res[] = ['path'=>$path,'status'=>0,'error'=>$r->get_error_message()]; continue; }
        $res[] = [
            'path'=>$path,
            'status'=> wp_remote_retrieve_response_code($r),
            'final'=> wp_remote_retrieve_header($r,'x-final-url') ?: $url
        ];
    }
    return $res;
}

function wtp_config_page(){
    if ( ! current_user_can('manage_options') ) return;
    $samples = isset($_POST['wtp_samples']) ? array_filter(array_map('trim', explode("\n", wp_unslash($_POST['wtp_samples'])))) : ['/','/pl/','/sitemap_index.xml','/category/fashion/','/nieistnieje/'];
    $tested = [];
    if ( isset($_POST['wtp_run']) ) $tested = wtp_test_redirects($samples);
    echo '<div class="wrap"><h1>WTP Config Probe</h1><style>
.wrap .wtp-card{background:#fff;border:1px solid #ccd0d4;border-radius:8px;padding:16px;margin:12px 0;box-shadow:0 1px 2px rgba(0,0,0,.04);}
.wrap .wtp-row{display:flex;gap:12px;flex-wrap:wrap}
.wrap .wtp-col{flex:1 1 320px}
.wtp-btn{display:block;width:100%;padding:12px 16px;font-size:16px;text-align:center;border-radius:6px;border:1px solid #2271b1;background:#2271b1;color:#fff;text-decoration:none;cursor:pointer}
.wtp-btn.secondary{background:#f6f7f7;color:#1d2327;border-color:#8c8f94}
.wtp-status{font-size:18px;margin-top:8px}
.wtp-ok{color:#1f7a1f;font-weight:600}
.wtp-bad{color:#b11f1f;font-weight:600}
.wtp-pre{background:#f6f7f7;padding:12px;border-radius:6px;max-height:380px;overflow:auto}
.wtp-badge{display:inline-block;padding:2px 8px;border-radius:999px;background:#f0f0f1;border:1px solid #dcdcde;margin-left:8px}
@media (max-width:782px){ .wtp-btn{font-size:17px;padding:14px 18px} }
</style>';
    echo '<div class="wtp-card"><h2>.htaccess</h2><pre class="wtp-pre">'.esc_html( print_r(wtp_htaccess_sections(), true) ).'</pre></div>';
    echo '<div class="wtp-card"><h2>wp-config.php (bezpieczne linie)</h2><pre class="wtp-pre">'.esc_html( print_r(wtp_safe_wp_config_lines(), true) ).'</pre></div>';
    echo '<div class="wtp-card"><h2>Test redirectów</h2>';
    echo '<form method="post"><textarea name="wtp_samples" style="width:100%;height:120px;">'.esc_textarea(implode("\n",$samples)).'</textarea><p><button class="wtp-btn" name="wtp_run" value="1">Sprawdź reguły redirect</button></p></form>';
    if ($tested) echo '<pre class="wtp-pre">'.esc_html(json_encode($tested, JSON_PRETTY_PRINT|JSON_UNESCAPED_SLASHES|JSON_UNESCAPED_UNICODE)).'</pre>';
    echo '</div></div>';
}
