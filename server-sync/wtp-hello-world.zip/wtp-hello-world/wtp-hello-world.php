<?php
/*
Plugin Name: WTP Hello World
Description: Testowa wtyczka Hello World dla WeekTopPick.
Version: 1.0.0
Author: WeekTopPick Autopilot
*/
if (!defined('ABSPATH')) exit;
add_action('admin_notices', function(){
    echo '<div class="notice notice-success"><p><strong>Hello World!</strong> from WTP.</p></div>';
});
