<?php
/**
 * Plugin Name: WTP AutoFixer
 * Description: Autonaprawy o niskim ryzyku: flush rewrite, robots fallback, test uploads, opcjonalna rekonstrukcja .htaccess, smart cache purge, memory boost (MU), wirtualna sitemap. Log + e‑mail (własny adres). Działa z WTP Health Check.
 * Version: 1.2.0
 * Author: WeekTopPick Autopilot
 * License: GPLv2 or later
 */

if ( ! defined( 'ABSPATH' ) ) exit;

class WTP_AutoFixer {
    const SLUG       = 'wtp-autofixer';
    const CAP        = 'manage_options';
    const CRON_HOOK  = 'wtp_autofixer_event';
    const OPTS_KEY   = 'wtp_autofixer_opts';
    const LOG_KEY    = 'wtp_autofixer_log'; // max 100 pozycji
    const MU_DIR     = 'wp-content/mu-plugins';
    const MU_FILE    = 'wp-content/mu-plugins/wtp-memory.php';

    public function __construct(){
        add_action('admin_menu', [$this,'menu']);
        add_action('admin_init', [$this,'register_settings']);
        add_action(self::CRON_HOOK, [$this,'cron_run']);
        register_activation_hook(__FILE__, [$this,'on_activate']);
        register_deactivation_hook(__FILE__, [$this,'on_deactivate']);
        add_action('do_robotstxt', [$this,'robots_fallback']);
        add_action('template_redirect', [$this,'maybe_output_virtual_sitemap'], 0);
    }

    public function on_activate(){
        if ( ! wp_next_scheduled(self::CRON_HOOK) ) {
            wp_schedule_event(time()+300, 'hourly', self::CRON_HOOK);
        }
        $opts = get_option(self::OPTS_KEY, []);
        $defaults = [
            'enabled'=>true,
            'risk_threshold'=>90,
            'allow_flush_rewrite'=>true,
            'enable_robots_fallback'=>true,
            'allow_uploads_touch'=>true,
            'allow_htaccess'=>false,
            'email_on_change'=>true,
            'notify_email'=>'', // NEW: custom recipient(s), CSV
            'allow_cache_purge'=>true,
            'cache_targets'=>['wp_super_cache','w3tc','litespeed','wp_rocket','autoptimize'],
            'allow_memory_boost'=>false,
            'memory_target'=>'128M',
            'allow_virtual_sitemap'=>true
        ];
        update_option(self::OPTS_KEY, array_merge($defaults, is_array($opts)?$opts:[]), false);
    }

    public function on_deactivate(){
        $ts = wp_next_scheduled(self::CRON_HOOK);
        if ($ts) wp_unschedule_event($ts, self::CRON_HOOK);
    }

    public function menu(){
        add_menu_page('WTP AutoFixer','WTP AutoFixer', self::CAP, self::SLUG, [$this,'render'],'dashicons-hammer',56);
    }

    public function register_settings(){
        register_setting(self::SLUG, self::OPTS_KEY);
    }

    private function log($action,$result,$details=''){
        $row = ['time'=>gmdate('c'),'action'=>$action,'result'=>$result,'details'=>$details];
        $log = get_option(self::LOG_KEY, []);
        if(!is_array($log)) $log=[];
        array_unshift($log,$row);
        $log = array_slice($log,0,100);
        update_option(self::LOG_KEY,$log,false);
        return $row;
    }

    public function render(){
        if (!current_user_can(self::CAP)) return;
        $o = get_option(self::OPTS_KEY, []);
        $o = wp_parse_args($o, [
            'enabled'=>true,'risk_threshold'=>90,'allow_flush_rewrite'=>true,'enable_robots_fallback'=>true,
            'allow_uploads_touch'=>true,'allow_htaccess'=>false,'email_on_change'=>true,'notify_email'=>'',
            'allow_cache_purge'=>true,'cache_targets'=>['wp_super_cache','w3tc','litespeed','wp_rocket','autoptimize'],
            'allow_memory_boost'=>false,'memory_target'=>'128M','allow_virtual_sitemap'=>true
        ]);
        $log = get_option(self::LOG_KEY, []);
        ?>
        <div class="wrap">
            <h1>WTP AutoFixer</h1>
            <p>Automatyczne, bezpieczne naprawy na podstawie raportu WTP Health Check.</p>
            <form method="post" action="options.php">
                <?php settings_fields(self::SLUG); ?>
                <table class="form-table">
                    <tr><th>Włącz AutoFixer</th><td><label><input type="checkbox" name="<?php echo self::OPTS_KEY; ?>[enabled]" <?php checked(!empty($o['enabled']));?>> Aktywne</label></td></tr>
                    <tr><th>Próg ryzyka</th><td><input type="number" min="0" max="100" name="<?php echo self::OPTS_KEY; ?>[risk_threshold]" value="<?php echo esc_attr(intval($o['risk_threshold']));?>"> (poniżej → naprawy)</td></tr>
                    <tr><th>Flush permalinków</th><td><label><input type="checkbox" name="<?php echo self::OPTS_KEY; ?>[allow_flush_rewrite]" <?php checked(!empty($o['allow_flush_rewrite']));?>> Zezwól</label></td></tr>
                    <tr><th>Fallback robots.txt</th><td><label><input type="checkbox" name="<?php echo self::OPTS_KEY; ?>[enable_robots_fallback]" <?php checked(!empty($o['enable_robots_fallback']));?>> Włącz</label></td></tr>
                    <tr><th>Test zapisu w uploads/</th><td><label><input type="checkbox" name="<?php echo self::OPTS_KEY; ?>[allow_uploads_touch]" <?php checked(!empty($o['allow_uploads_touch']));?>> Zezwól</label></td></tr>
                    <tr><th>Rekonstrukcja .htaccess</th><td><label><input type="checkbox" name="<?php echo self::OPTS_KEY; ?>[allow_htaccess]" <?php checked(!empty($o['allow_htaccess']));?>> Zezwól (Apache)</label></td></tr>
                    <tr><th>Powiadomienia e‑mail</th>
                        <td>
                            <label><input type="checkbox" name="<?php echo self::OPTS_KEY; ?>[email_on_change]" <?php checked(!empty($o['email_on_change']));?>> Wyślij po zmianach</label><br>
                            <label>Adres(y) e‑mail (opcjonalnie, CSV): <input type="text" name="<?php echo self::OPTS_KEY; ?>[notify_email]" value="<?php echo esc_attr($o['notify_email']);?>" class="regular-text" style="width:60%"></label>
                            <p class="description">Jeśli puste → wyślemy na globalny <code>admin_email</code>. Możesz podać kilka adresów oddzielonych przecinkami.</p>
                        </td></tr>
                    <tr><th colspan="2"><hr /></th></tr>
                    <tr><th>Smart cache purge</th>
                        <td>
                            <label><input type="checkbox" name="<?php echo self::OPTS_KEY; ?>[allow_cache_purge]" <?php checked(!empty($o['allow_cache_purge']));?>> Włącz</label>
                            <p class="description">Obsługiwane: WP Super Cache, W3 Total Cache, LiteSpeed Cache, WP Rocket, Autoptimize.</p>
                        </td></tr>
                    <tr><th>Memory boost (MU)</th>
                        <td>
                            <label><input type="checkbox" name="<?php echo self::OPTS_KEY; ?>[allow_memory_boost]" <?php checked(!empty($o['allow_memory_boost']));?>> Podnieś limit do</label>
                            <input type="text" name="<?php echo self::OPTS_KEY; ?>[memory_target]" value="<?php echo esc_attr($o['memory_target']);?>" style="width: 100px;"> (np. 128M, 256M)
                            <p class="description">Tworzy plik MU-plugin (wtp-memory.php), jeśli katalog <code>wp-content/mu-plugins/</code> jest zapisywalny.</p>
                        </td></tr>
                    <tr><th>Wirtualna sitemap</th><td><label><input type="checkbox" name="<?php echo self::OPTS_KEY; ?>[allow_virtual_sitemap]" <?php checked(!empty($o['allow_virtual_sitemap']));?>> Serwuj <code>/sitemap_index.xml</code> jeśli brak SEO</label></td></tr>
                </table>
                <p><button class="button button-primary">Zapisz</button></p>
            </form>

            <h2>Log (ostatnie 100)</h2>
            <table class="widefat striped">
                <thead><tr><th>Time</th><th>Action</th><th>Result</th><th>Details</th></tr></thead>
                <tbody>
                <?php foreach($log as $r): ?>
                  <tr><td><?php echo esc_html($r['time']);?></td><td><?php echo esc_html($r['action']);?></td><td><?php echo esc_html($r['result']);?></td><td><?php echo esc_html($r['details']);?></td></tr>
                <?php endforeach; ?>
                </tbody>
            </table>
        </div>
        <?php
    }

    public function robots_fallback(){
        $o = get_option(self::OPTS_KEY, []);
        if(empty($o['enable_robots_fallback'])) return;
        echo "User-agent: *\n";
        echo "Disallow:\n";
        echo "Sitemap: ".esc_url(home_url('/sitemap_index.xml'))."\n";
    }

    public function maybe_output_virtual_sitemap(){
        $o = get_option(self::OPTS_KEY, []);
        if (empty($o['allow_virtual_sitemap'])) return;
        $has_seo = class_exists('WPSEO_Sitemaps') || class_exists('All_in_One_SEO_Pack') || class_exists('RankMath');
        if ($has_seo) return;
        $req_uri = isset($_SERVER['REQUEST_URI']) ? $_SERVER['REQUEST_URI'] : '';
        if (false !== strpos($req_uri, '/sitemap_index.xml')){
            header('Content-Type: application/xml; charset=UTF-8');
            echo '<?xml version="1.0" encoding="UTF-8"?>'."\n";
            echo '<sitemapindex xmlns="http://www.sitemaps.org/schemas/sitemap/0.9">';
            echo '<sitemap><loc>'.esc_url(home_url('/')).'</loc></sitemap>';
            echo '<sitemap><loc>'.esc_url(home_url('/robots.txt')).'</loc></sitemap>';
            echo '</sitemapindex>';
            exit;
        }
    }

    private function get_health(){
        if ( ! function_exists('rest_do_request') ) return null;
        $req = new \WP_REST_Request('GET','/wtp/v1/health');
        $resp = rest_do_request($req);
        if ($resp instanceof \WP_REST_Response) return $resp->get_data();
        return null;
    }

    private function email($subject,$message){
        $o = get_option(self::OPTS_KEY, []);
        $custom = isset($o['notify_email']) ? trim($o['notify_email']) : '';
        if ($custom){
            // split CSV and validate basic format
            $parts = array_filter(array_map('trim', explode(',', $custom)));
            $to = [];
            foreach ($parts as $p){
                if (is_email($p)) $to[] = $p;
            }
            if (!$to) $to = [ get_option('admin_email') ];
        } else {
            $to = [ get_option('admin_email') ];
        }
        wp_mail($to, $subject, $message);
    }

    private function smart_cache_purge(){
        $purged = [];
        if ( function_exists('wp_cache_clear_cache') ){ wp_cache_clear_cache(); $purged[]='wp_super_cache'; }
        if ( function_exists('w3tc_flush_all') ){ w3tc_flush_all(); $purged[]='w3tc'; }
        do_action('w3tc_flush_all');
        if ( function_exists('do_action') ){ do_action('litespeed_purge_all'); $purged[]='litespeed'; }
        if ( function_exists('rocket_clean_domain') ){ rocket_clean_domain(); $purged[]='wp_rocket'; }
        do_action('autoptimize_flush_cache'); $purged[]='autoptimize';
        return $purged;
    }

    private function ensure_mu_memory($target='128M'){
        $mu_dir = trailingslashit(ABSPATH).'wp-content/mu-plugins';
        if ( ! is_dir($mu_dir) ){
            if ( ! is_writable(trailingslashit(ABSPATH).'wp-content') ) return 'mu-plugins not writable';
            if ( ! @mkdir($mu_dir) ) return 'cannot create mu-plugins';
        }
        if ( ! is_writable($mu_dir) ) return 'mu-plugins not writable';
        $file = $mu_dir.'/wtp-memory.php';
        $php = "<?php\n";
        $php .= "/* WTP: force memory limit if needed */\n";
        $php .= "if (!defined('WP_MEMORY_LIMIT')) define('WP_MEMORY_LIMIT', '".esc_attr($target)."');\n";
        $php .= "if (function_exists('ini_set')) @ini_set('memory_limit','".esc_attr($target)."');\n";
        if ( @file_put_contents($file, $php)!==false ) return 'ok';
        return 'write fail';
    }

    public function cron_run(){
        $o = get_option(self::OPTS_KEY, []);
        if (empty($o['enabled'])) return;

        $data = $this->get_health();
        if (!$data) { $this->log('health','fail','no data'); return; }

        $changed = []; $notes=[];
        $risk = isset($data['risk_score']) ? intval($data['risk_score']) : 100;

        // 1) Flush rewrite
        if (!empty($o['allow_flush_rewrite'])){
            $need_flush = false;
            foreach ((array)$data['urls'] as $u){
                if (in_array(parse_url($u['url'],PHP_URL_PATH), ['/', '/robots.txt'], true) && intval($u['status']) !== 200){
                    $need_flush = true; break;
                }
            }
            if ($need_flush || $risk < intval($o['risk_threshold'])) {
                flush_rewrite_rules(false);
                $this->log('flush_rewrite','ok','auto');
                $changed[]='flush_rewrite';
            }
        }

        // 2) uploads/ touch
        if (!empty($o['allow_uploads_touch'])){
            $up = wp_get_upload_dir();
            $test = trailingslashit($up['basedir']).'wtp-touch.tmp';
            $ok = @file_put_contents($test, 'ok') !== false;
            if ($ok){ @unlink($test); $this->log('uploads_touch','ok',$up['basedir']); }
            else { $this->log('uploads_touch','fail',$up['basedir']); $notes[]='uploads not writable'; }
        }

        // 3) .htaccess
        if (!empty($o['allow_htaccess'])){
            if ( function_exists('got_mod_rewrite') && got_mod_rewrite() ){
                $file = ABSPATH.'.htaccess';
                if ( ! file_exists($file) || ! filesize($file) ){
                    $rules = self::default_htaccess_rules();
                    if ( is_writable(ABSPATH) ){
                        @file_put_contents($file, $rules);
                        $this->log('htaccess_write','ok','default rules');
                        $changed[]='htaccess_write';
                    } else {
                        $this->log('htaccess_write','fail','not writable');
                        $notes[]='.htaccess not writable';
                    }
                }
            }
        }

        // 4) Cache purge
        if (!empty($o['allow_cache_purge'])){
            $purged = $this->smart_cache_purge();
            if ($purged){ $this->log('cache_purge','ok', implode(',', $purged)); $changed[]='cache_purge'; }
        }

        // 5) Memory boost
        if (!empty($o['allow_memory_boost'])){
            $target = !empty($o['memory_target']) ? $o['memory_target'] : '128M';
            $res = $this->ensure_mu_memory($target);
            $this->log('memory_boost',$res,$target);
            if ($res==='ok') $changed[]='memory_boost';
        }

        if ($changed && !empty($o['email_on_change'])){
            $this->email('WTP AutoFixer: wykonano akcje', "Wykonano: ".implode(', ',$changed)."\nUwagi: ".implode(', ',$notes)."\nSite: ".home_url('/')."\nTime: ".gmdate('c'));
        }
    }

    private static function default_htaccess_rules(){
        return <<<HT
# BEGIN WordPress
<IfModule mod_rewrite.c>
RewriteEngine On
RewriteBase /
RewriteRule ^index\.php$ - [L]
RewriteCond %{REQUEST_FILENAME} !-f
RewriteCond %{REQUEST_FILENAME} !-d
RewriteRule . /index.php [L]
</IfModule>
# END WordPress
HT;
    }
}
new WTP_AutoFixer();
