<?php
namespace WTP\SEO\Features; if(!defined('ABSPATH')) exit;
class Logger404{
  const MAX=1000;
  function __construct(){ \add_action('template_redirect',[$this,'log'],99); }
  function log(){
    if(!\is_404()) return; $url=$_SERVER['REQUEST_URI']??''; $ref=$_SERVER['HTTP_REFERER']??''; $ua=$_SERVER['HTTP_USER_AGENT']??'';
    $log=(array)\get_option('wtp_404_log',[]); $found=false;
    foreach($log as &$r){ if(($r['url']??'')===$url){ $r['count']=(int)($r['count']??0)+1; $r['last_seen']=\current_time('mysql'); $found=true; break; } }
    if(!$found){ $log[]=['url'=>$url,'referrer'=>$ref,'ua'=>$ua,'count'=>1,'last_seen'=>\current_time('mysql')]; }
    if(count($log)>self::MAX) $log=array_slice($log,-self::MAX);
    \update_option('wtp_404_log',$log,false);
  }
}
