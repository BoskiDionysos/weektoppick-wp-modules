<?php
namespace WTP\SEO\Features; if(!defined('ABSPATH')) exit;
class TaxMeta{
  private $keys=[ 'wtp_seo_title'=>'SEO Title','wtp_meta_description'=>'Meta Description','wtp_focus_keyword'=>'Focus Keyword','wtp_keywords'=>'Keywords (comma separated)' ];
  function __construct(){ \add_action('category_edit_form_fields',[$this,'render']); \add_action('edited_category',[$this,'save']); \add_action('created_category',[$this,'save']); }
  function render($term){
    if(!\current_user_can('manage_wtp_seo')) return; \wp_nonce_field('wtp_save_term_meta','wtp_term_nonce');
    foreach($this->keys as $k=>$label){ $v=\get_term_meta($term->term_id,$k,true); echo '<tr class="form-field"><th scope="row"><label for="'.$k.'">'.\esc_html($label).'</label></th><td>'; 
      if($k==='wtp_meta_description'){ echo '<textarea name="'.$k.'" id="'.$k.'" rows="4" class="large-text">'.\esc_textarea($v).'</textarea>'; } else { echo '<input type="text" name="'.$k.'" id="'.$k.'" value="'.\esc_attr($v).'" class="regular-text"/>'; } 
      echo '</td></tr>'; }
  }
  function save($term_id){
    if(!\current_user_can('manage_wtp_seo')) return; if(!isset($_POST['wtp_term_nonce'])||!\wp_verify_nonce($_POST['wtp_term_nonce'],'wtp_save_term_meta')) return;
    foreach($this->keys as $k=>$label){ $val=$_POST[$k]??''; $clean=($k==='wtp_meta_description')?\wp_strip_all_tags($val):\sanitize_text_field($val); \update_term_meta($term_id,$k,$clean); }
  }
}
