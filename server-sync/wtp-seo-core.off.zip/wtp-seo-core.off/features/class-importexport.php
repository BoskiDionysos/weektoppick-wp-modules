<?php
namespace WTP\SEO\Features; if(!defined('ABSPATH')) exit;
class ImportExport{
  static function export_json(){
    $data=[ 'version'=>\get_option('wtp_seo_db_version','0.3.5'),
      'settings'=>[ 'locales'=>\get_option('wtp_locales',''), 'legacy_keywords'=>(bool)\get_option('wtp_legacy_keywords',0), 'events'=>(array)\get_option('wtp_events',[]) ],
      'templates'=>[ 'post'=>['title'=>\get_option('wtp_tpl_post_title',''),'desc'=>\get_option('wtp_tpl_post_desc','')], 'page'=>['title'=>\get_option('wtp_tpl_page_title',''),'desc'=>\get_option('wtp_tpl_page_desc','')] ],
      'redirects'=>(array)\get_option('wtp_redirects',[])
    ];
    $json=\wp_json_encode($data, JSON_PRETTY_PRINT); \header('Content-Type: application/json'); \header('Content-Disposition: attachment; filename="wtp-seo-export.json"'); echo $json;
  }
  static function import_json($file,$dry=true){
    if(!$file||empty($file['tmp_name'])){ echo '<div class="error"><p>No file.</p></div>'; return; }
    $raw=\file_get_contents($file['tmp_name']); $data=json_decode($raw,true); if(!$data){ echo '<div class="error"><p>Invalid JSON.</p></div>'; return; }
    $changes=[];
    if(isset($data['settings']['locales'])){ $changes[]='Locales: '.$data['settings']['locales']; if(!$dry) \update_option('wtp_locales',$data['settings']['locales'],false); }
    if(isset($data['settings']['legacy_keywords'])){ $changes[]='Legacy keywords: '.($data['settings']['legacy_keywords']?'on':'off'); if(!$dry) \update_option('wtp_legacy_keywords',$data['settings']['legacy_keywords']?1:0,false); }
    if(isset($data['settings']['events'])){ $changes[]='Events mapping set'; if(!$dry) \update_option('wtp_events',(array)$data['settings']['events'],false); }
    if(isset($data['templates'])){ if(!$dry){ \update_option('wtp_tpl_post_title',$data['templates']['post']['title']??'',false); \update_option('wtp_tpl_post_desc',$data['templates']['post']['desc']??'',false); \update_option('wtp_tpl_page_title',$data['templates']['page']['title']??'',false); \update_option('wtp_tpl_page_desc',$data['templates']['page']['desc']??'',false);} $changes[]='Templates updated'; }
    if(isset($data['redirects'])){ $cnt=count((array)$data['redirects']); $changes[]='Redirects: '.$cnt; if(!$dry) \update_option('wtp_redirects',(array)$data['redirects'],false); }
    echo '<div class="updated"><p>'.($dry?'[Dry-run] ':'').\esc_html(implode(' | ',$changes)).'</p></div>';
  }
  static function import_csv($redir,$cats,$dry=true){
    if($redir and !empty($redir['tmp_name'])){
      $rows=self::csv($redir['tmp_name']); $existing=(array)\get_option('wtp_redirects',[]); $i=0;
      foreach($rows as $r){ if(!isset($r['pattern'],$r['target'])) continue; $existing[]=[ 'id'=>time().rand(100,999),'pattern'=>\sanitize_text_field($r['pattern']),'target'=>\sanitize_text_field($r['target']),'status'=>(int)($r['status']??301),'regex'=>!empty($r['regex']),'hits'=>0,'created_at'=>\current_time('mysql'),'updated_at'=>\current_time('mysql') ]; $i++; }
      if(!$dry) \update_option('wtp_redirects',$existing,false); echo '<div class="updated"><p>'.($dry?'[Dry-run] ':'').'Imported redirects: '.$i.'</p></div>';
    }
    if($cats and !empty($cats['tmp_name'])){
      $rows=self::csv($cats['tmp_name']); $i=0; foreach($rows as $r){ if(($r['taxonomy']??'')!=='category') continue; $id=(int)($r['term_id']??0); if(!$id) continue;
        $map=[ 'wtp_seo_title'=>$r['seo_title']??'', 'wtp_meta_description'=>$r['meta_desc']??'', 'wtp_focus_keyword'=>$r['focus_keyword']??'', 'wtp_keywords'=>$r['keywords']??'' ];
        foreach($map as $k=>$v){ if(!$dry) \update_term_meta($id,$k,\sanitize_text_field($v)); } $i++;
      }
      echo '<div class="updated"><p>'.($dry?'[Dry-run] ':'').'Updated category SEO rows: '.$i.'</p></div>';
    }
  }
  private static function csv($path){ $out=[]; if(($h=fopen($path,'r'))!==false){ $hdr=fgetcsv($h); if($hdr){ while(($r=fgetcsv($h))!==false){ $row=[]; foreach($hdr as $i=>$k){ $row[trim($k)]=$r[$i]??''; } $out[]=$row; } } fclose($h);} return $out; }
}
