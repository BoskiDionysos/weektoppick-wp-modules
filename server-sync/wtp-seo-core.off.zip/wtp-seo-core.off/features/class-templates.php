<?php
namespace WTP\SEO\Features; if(!defined('ABSPATH')) exit;
class Templates{
  function __construct(){ \add_filter('pre_get_document_title',[$this,'title'],20); \add_action('wp_head',[$this,'meta'],1); }
  private function tokens($tpl){
    $repl=[ '{title}'=>\wp_get_document_title(), '{site_name}'=>\get_bloginfo('name'), '{sep}'=>'–', '{excerpt}'=>$this->excerpt() ];
    return strtr($tpl,$repl);
  }
  private function excerpt(){
    if(\is_singular()){ global $post; $txt=\has_excerpt($post)?\get_the_excerpt($post):\wp_trim_words(\wp_strip_all_tags($post->post_content),25); return $txt; }
    return \get_bloginfo('description');
  }
  function title($title){
    if(\is_singular('post')){ $tpl=\get_option('wtp_tpl_post_title',''); if($tpl) return $this->tokens($tpl); }
    elseif(\is_page()){ $tpl=\get_option('wtp_tpl_page_title',''); if($tpl) return $this->tokens($tpl); }
    return $title;
  }
  function meta(){
    $desc=''; if(\is_singular('post')){ $t=\get_option('wtp_tpl_post_desc',''); if($t) $desc=$this->tokens($t); }
    elseif(\is_page()){ $t=\get_option('wtp_tpl_page_desc',''); if($t) $desc=$this->tokens($t); }
    if($desc) echo '<meta name="description" content="'.\esc_attr($desc).'" />'."\n";
    if((int)\get_option('wtp_legacy_keywords',0) && \is_category()){ $term=\get_queried_object(); if($term){ $kw=\get_term_meta($term->term_id,'wtp_keywords',true); if($kw) echo '<meta name="keywords" content="'.\esc_attr($kw).'" />'."\n"; } }
  }
}
