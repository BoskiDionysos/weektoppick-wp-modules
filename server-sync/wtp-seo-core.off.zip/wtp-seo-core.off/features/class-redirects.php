<?php
namespace WTP\SEO\Features; if(!defined('ABSPATH')) exit;
class Redirects{
  function __construct(){ \add_action('template_redirect',[$this,'go'],0); }
  function go(){
    if(\is_admin()||\is_feed()||\is_robots()||\defined('REST_REQUEST')) return;
    $rows=(array)\get_option('wtp_redirects',[]); if(!$rows) return;
    $uri=$_SERVER['REQUEST_URI']??'/'; $path=\wp_parse_url($uri,PHP_URL_PATH); $norm=rtrim($path?:'/','/');
    foreach($rows as $r){
      $p=$r['pattern']??''; $t=$r['target']??''; $status=(int)($r['status']??301); $regex=!empty($r['regex']); if(!$p||!$t) continue;
      $match=false; $dest=$t;
      if($regex){ $del='@'; if(\preg_match($del.$p.$del,$uri)) { $match=true; $dest=\preg_replace($del.$p.$del,$t,$uri);} }
      else { if(rtrim($p,'/')===$norm) $match=true; }
      if($match){
        if(strpos($dest,'http')!==0) $dest=\home_url($dest);
        if(\home_url($uri)===$dest) continue;
        $this->hit($r['id']??null); \wp_redirect($dest,$status); exit;
      }
    }
  }
  private function hit($id){
    if(!$id) return; $rows=(array)\get_option('wtp_redirects',[]);
    foreach($rows as &$row){ if((string)$row['id']===(string)$id){ $row['hits']=(int)($row['hits']??0)+1; $row['updated_at']=\current_time('mysql'); break; } }
    \update_option('wtp_redirects',$rows,false);
  }
}
