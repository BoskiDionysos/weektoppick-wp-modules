<?php
namespace WTP\SEO\Features; if(!defined('ABSPATH')) exit;
class AnalyticsFeat{}
