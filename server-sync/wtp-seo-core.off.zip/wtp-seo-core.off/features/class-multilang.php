<?php
namespace WTP\SEO\Features; if(!defined('ABSPATH')) exit;
class Multilang{
  function __construct(){ \add_action('wp_head',[$this,'hreflang'],2); }
  function hreflang(){
    $loc=\get_option('wtp_locales',''); if(!$loc) return; $arr=array_filter(array_map('trim',explode(',',$loc))); if(!$arr) return;
    $uri=$_SERVER['REQUEST_URI']??'/';
    foreach($arr as $lc){ echo '<link rel="alternate" hreflang="'.\esc_attr($lc).'" href="'.\esc_url(\home_url('/'.$lc.$uri)).'" />'."\n"; }
    echo '<link rel="alternate" hreflang="x-default" href="'.\esc_url(\home_url($uri)).'" />'."\n";
  }
}
