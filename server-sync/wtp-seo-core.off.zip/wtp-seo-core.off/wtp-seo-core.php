<?php
/**
 * Plugin Name: WTP SEO Core
 * Description: WTP SEO Core: taxonomy SEO fields, templates, redirects, 404 monitor, hreflang, analytics mapping, import/export.
 * Version: 0.3.5
 * Author: WeekTopPick
 * Requires PHP: 8.0
 * Requires at least: 6.0
 */
namespace WTP\SEO;
if (!defined('ABSPATH')) exit;

define('WTP_SEO_VERSION','0.3.5');
define('WTP_SEO_DIR', plugin_dir_path(__FILE__));

function ensure_caps(){
  foreach(['administrator','editor'] as $r){ $role=\get_role($r); if($role && !$role->has_cap('manage_wtp_seo')) $role->add_cap('manage_wtp_seo'); }
}
\add_action('admin_init', __NAMESPACE__.'\\ensure_caps');
\register_activation_hook(__FILE__, function(){
  ensure_caps();
  if(!\get_option('wtp_locales')) \update_option('wtp_locales','en,pl,it,de,fr,es,pt',false);
  if(!\get_option('wtp_events')) \update_option('wtp_events',[ 'affiliate_click'=>'affiliate_click','newsletter_signup'=>'newsletter_signup','language_select'=>'language_select' ],false);
  if(!\get_option('wtp_redirects')) \update_option('wtp_redirects',[],false);
  if(!\get_option('wtp_404_log')) \update_option('wtp_404_log',[],false);
  \update_option('wtp_seo_db_version','0.3.5',false);
});

require_once WTP_SEO_DIR.'admin/class-admin-menu.php';
require_once WTP_SEO_DIR.'admin/class-admin-settings.php';
require_once WTP_SEO_DIR.'admin/class-admin-redirects.php';
require_once WTP_SEO_DIR.'admin/class-admin-404.php';
require_once WTP_SEO_DIR.'admin/class-admin-templates.php';
require_once WTP_SEO_DIR.'admin/class-admin-multilang.php';
require_once WTP_SEO_DIR.'admin/class-admin-analytics.php';
require_once WTP_SEO_DIR.'admin/class-admin-importexport.php';
require_once WTP_SEO_DIR.'features/class-tax-meta.php';
require_once WTP_SEO_DIR.'features/class-redirects.php';
require_once WTP_SEO_DIR.'features/class-404.php';
require_once WTP_SEO_DIR.'features/class-templates.php';
require_once WTP_SEO_DIR.'features/class-multilang.php';
require_once WTP_SEO_DIR.'features/class-analytics.php';
require_once WTP_SEO_DIR.'features/class-importexport.php';

\add_action('plugins_loaded', function(){
  new \WTP\SEO\Admin\Menu();
  new \WTP\SEO\Features\TaxMeta();
  new \WTP\SEO\Features\Redirects();
  new \WTP\SEO\Features\Logger404();
  new \WTP\SEO\Features\Templates();
  new \WTP\SEO\Features\Multilang();
  new \WTP\SEO\Features\AnalyticsFeat();
  new \WTP\SEO\Features\ImportExport();
});
