WTP SEO Core v0.3.5
- Category SEO fields (termmeta): wtp_seo_title, wtp_meta_description, wtp_focus_keyword, wtp_keywords
- Templates tokens: {title} {site_name} {sep} {excerpt}
- Redirects (301/302, regex), 404 monitor, hreflang, analytics mapping
- Import/Export JSON + CSV (redirects.csv, categories-seo.csv)