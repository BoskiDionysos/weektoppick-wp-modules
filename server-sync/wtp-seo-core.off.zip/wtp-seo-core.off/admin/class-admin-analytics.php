<?php
namespace WTP\SEO\Admin; if(!defined('ABSPATH')) exit;
class AnalyticsAdmin{
  static function render(){
    if(!\current_user_can('manage_wtp_seo')) return; $ev=(array)\get_option('wtp_events',[]);
    echo '<div class="wrap"><h1>Analytics</h1><p>Mapping from Settings:</p>';
    echo '<p><code>affiliate_click</code> → '.\esc_html($ev['affiliate_click']??'affiliate_click').'</p>';
    echo '<p><code>newsletter_signup</code> → '.\esc_html($ev['newsletter_signup']??'newsletter_signup').'</p>';
    echo '<p><code>language_select</code> → '.\esc_html($ev['language_select']??'language_select').'</p></div>';
  }
}
