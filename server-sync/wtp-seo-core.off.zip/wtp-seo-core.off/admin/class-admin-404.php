<?php
namespace WTP\SEO\Admin; if(!defined('ABSPATH')) exit;
class Monitor404{
  static function render(){
    if(!\current_user_can('manage_wtp_seo')) return;
    $log=(array)\get_option('wtp_404_log',[]);
    echo '<div class="wrap"><h1>404 Monitor</h1><table class="widefat"><thead><tr><th>URL</th><th>Referrer</th><th>User-Agent</th><th>Count</th><th>Last seen</th></tr></thead><tbody>';
    if(!$log){ echo '<tr><td colspan="5">No 404s.</td></tr>'; } else {
      foreach($log as $r){ echo '<tr><td><code>'.\esc_html($r['url']).'</code></td><td>'.\esc_html($r['referrer']).'</td><td>'.\esc_html($r['ua']).'</td><td>'.\esc_html($r['count']).'</td><td>'.\esc_html($r['last_seen']).'</td></tr>'; }
    }
    echo '</tbody></table></div>';
  }
}
