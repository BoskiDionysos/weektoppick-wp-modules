<?php
namespace WTP\SEO\Admin; if(!defined('ABSPATH')) exit;
class TemplatesAdmin{
  static function render(){
    if(!\current_user_can('manage_wtp_seo')) return;
    if(isset($_POST['wtp_templates_nonce']) && \wp_verify_nonce($_POST['wtp_templates_nonce'],'wtp_templates_save')){
      \update_option('wtp_tpl_post_title', \sanitize_text_field($_POST['post_title_tpl']??''), false);
      \update_option('wtp_tpl_post_desc', \sanitize_text_field($_POST['post_desc_tpl']??''), false);
      \update_option('wtp_tpl_page_title', \sanitize_text_field($_POST['page_title_tpl']??''), false);
      \update_option('wtp_tpl_page_desc', \sanitize_text_field($_POST['page_desc_tpl']??''), false);
      echo '<div class="updated"><p>Templates saved.</p></div>';
    }
    $pt=\get_option('wtp_tpl_post_title','{title} {sep} {site_name}'); $pd=\get_option('wtp_tpl_post_desc','{excerpt}'); $gt=\get_option('wtp_tpl_page_title','{title} {sep} {site_name}'); $gd=\get_option('wtp_tpl_page_desc','{excerpt}');
    echo '<div class="wrap"><h1>Meta Templates</h1><p>Tokens: <code>{title}</code> <code>{site_name}</code> <code>{sep}</code> <code>{excerpt}</code></p><form method="post">'; \wp_nonce_field('wtp_templates_save','wtp_templates_nonce');
    echo '<h2>Post</h2><p>Title template<br><input name="post_title_tpl" value="'.\esc_attr($pt).'" style="width:600px"/></p><p>Description template<br><input name="post_desc_tpl" value="'.\esc_attr($pd).'" style="width:600px"/></p>';
    echo '<h2>Page</h2><p>Title template<br><input name="page_title_tpl" value="'.\esc_attr($gt).'" style="width:600px"/></p><p>Description template<br><input name="page_desc_tpl" value="'.\esc_attr($gd).'" style="width:600px"/></p>';
    echo '<p><button class="button button-primary">Save Templates</button></p></form></div>';
  }
}
