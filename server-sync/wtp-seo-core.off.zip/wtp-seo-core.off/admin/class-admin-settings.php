<?php
namespace WTP\SEO\Admin; if(!defined('ABSPATH')) exit;
class Settings{
  static function render(){
    if(!\current_user_can('manage_wtp_seo')) return;
    if(isset($_POST['wtp_settings_nonce']) && \wp_verify_nonce($_POST['wtp_settings_nonce'],'wtp_save_settings')){
      \update_option('wtp_locales', \sanitize_text_field($_POST['wtp_locales']??''), false);
      \update_option('wtp_legacy_keywords', !empty($_POST['wtp_legacy_keywords'])?1:0, false);
      $ev=[
        'affiliate_click'=>\sanitize_text_field($_POST['wtp_evt_aff']??'affiliate_click'),
        'newsletter_signup'=>\sanitize_text_field($_POST['wtp_evt_news']??'newsletter_signup'),
        'language_select'=>\sanitize_text_field($_POST['wtp_evt_lang']??'language_select'),
      ];
      \update_option('wtp_events',$ev,false);
      echo '<div class="updated"><p>Settings saved.</p></div>';
    }
    $loc=\get_option('wtp_locales','en,pl,it,de,fr,es,pt'); $legacy=(int)\get_option('wtp_legacy_keywords',0); $ev=(array)\get_option('wtp_events',[]);
    echo '<div class="wrap"><h1>Settings</h1><form method="post">'; \wp_nonce_field('wtp_save_settings','wtp_settings_nonce');
    echo '<h2>Multilang & Hreflang</h2><p><label>Locales: <input type="text" name="wtp_locales" value="'.\esc_attr($loc).'" placeholder="en,pl,it,de,fr,es,pt" style="width:400px"/></label></p>';
    echo '<h2>Legacy</h2><p><label><input type="checkbox" name="wtp_legacy_keywords" '.($legacy?'checked':'').'/> Enable legacy &lt;meta name="keywords"&gt;</label></p>';
    echo '<h2>Analytics events</h2>';
    echo '<p><code>affiliate_click</code> → <input name="wtp_evt_aff" value="'.\esc_attr($ev['affiliate_click']??'affiliate_click').'" /></p>';
    echo '<p><code>newsletter_signup</code> → <input name="wtp_evt_news" value="'.\esc_attr($ev['newsletter_signup']??'newsletter_signup').'" /></p>';
    echo '<p><code>language_select</code> → <input name="wtp_evt_lang" value="'.\esc_attr($ev['language_select']??'language_select').'" /></p>';
    echo '<p><button class="button button-primary">Save Changes</button></p></form></div>';
  }
}
