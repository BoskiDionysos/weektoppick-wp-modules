<?php
namespace WTP\SEO\Admin; if(!defined('ABSPATH')) exit;
class RedirectsAdmin{
  static function render(){
    if(!\current_user_can('manage_wtp_seo')) return;
    $rows=(array)\get_option('wtp_redirects',[]);
    if(isset($_POST['wtp_redirects_nonce']) && \wp_verify_nonce($_POST['wtp_redirects_nonce'],'wtp_redirects_save')){
      if(isset($_POST['add_redirect'])){
        $rows[]=[ 'id'=>time().rand(100,999), 'pattern'=>\sanitize_text_field($_POST['pattern']??''), 'target'=>\sanitize_text_field($_POST['target']??''), 'status'=>(int)($_POST['status']??301), 'regex'=>!empty($_POST['regex']), 'hits'=>0, 'created_at'=>\current_time('mysql'), 'updated_at'=>\current_time('mysql') ];
        \update_option('wtp_redirects',$rows,false); echo '<div class="updated"><p>Redirect added.</p></div>';
      }
      if(isset($_POST['delete_redirect'])){
        $rid=\sanitize_text_field($_POST['rid']??''); $rows=array_values(array_filter($rows,function($r)use($rid){return (string)$r['id']!==(string)$rid;})); \update_option('wtp_redirects',$rows,false);
        echo '<div class="updated"><p>Redirect deleted.</p></div>';
      }
    }
    echo '<div class="wrap"><h1>Redirects</h1><form method="post" style="margin-bottom:12px">'; \wp_nonce_field('wtp_redirects_save','wtp_redirects_nonce');
    echo '<input name="pattern" placeholder="/old/(.*)" style="width:260px"/> <input name="target" placeholder="/new/$1" style="width:260px"/> ';
    echo '<select name="status"><option>301</option><option>302</option></select> <label><input type="checkbox" name="regex"/> regex</label> ';
    echo '<button class="button button-primary" name="add_redirect" value="1">Add redirect</button></form>';
    echo '<table class="widefat"><thead><tr><th>ID</th><th>Pattern</th><th>Target</th><th>Status</th><th>Regex</th><th>Hits</th><th>Actions</th></tr></thead><tbody>';
    if(!$rows){ echo '<tr><td colspan="7">No redirects.</td></tr>'; } else {
      foreach($rows as $r){ echo '<tr><td>'.\esc_html($r['id']).'</td><td><code>'.\esc_html($r['pattern']).'</code></td><td><code>'.\esc_html($r['target']).'</code></td><td>'.\esc_html($r['status']).'</td><td>'.($r['regex']?'yes':'no').'</td><td>'.\esc_html($r['hits']??0).'</td><td><form method="post" style="display:inline">'; \wp_nonce_field('wtp_redirects_save','wtp_redirects_nonce'); echo '<input type="hidden" name="rid" value="'.\esc_attr($r['id']).'"/><button class="button button-small" name="delete_redirect" value="1" onclick="return confirm(\'Delete?\')">Delete</button></form></td></tr>'; }
    }
    echo '</tbody></table></div>';
  }
}
