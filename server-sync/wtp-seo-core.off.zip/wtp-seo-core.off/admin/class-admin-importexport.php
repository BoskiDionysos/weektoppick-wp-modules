<?php
namespace WTP\SEO\Admin; if(!defined('ABSPATH')) exit; use WTP\SEO\Features\ImportExport;
class ImportExportAdmin{
  static function render(){
    if(!\current_user_can('manage_wtp_seo')) return;
    echo '<div class="wrap"><h1>Import/Export</h1>';
    echo '<h2>Export JSON</h2><form method="post">'; \wp_nonce_field('wtp_export_json','wtp_export_json'); echo '<button class="button button-primary" name="do_export_json" value="1">Download JSON export</button></form>';
    echo '<h2>Import JSON</h2><form method="post" enctype="multipart/form-data">'; \wp_nonce_field('wtp_import_json','wtp_import_json'); echo '<input type="file" name="json_file" accept=".json"/> <label><input type="checkbox" name="dry_run" checked/> Dry run</label> <button class="button" name="do_import_json" value="1">Import JSON</button></form>';
    echo '<h2>Import CSV</h2><form method="post" enctype="multipart/form-data">'; \wp_nonce_field('wtp_import_csv','wtp_import_csv'); echo '<p>Redirects: <input type="file" name="redirects_csv" accept=".csv"/></p><p>Categories SEO: <input type="file" name="categories_csv" accept=".csv"/></p><label><input type="checkbox" name="dry_run" checked/> Dry run</label> <button class="button" name="do_import_csv" value="1">Import CSV</button></form>';
    if(isset($_POST['do_export_json']) && \wp_verify_nonce($_POST['wtp_export_json']??'','wtp_export_json')){ ImportExport::export_json(); exit; }
    if(isset($_POST['do_import_json']) && \wp_verify_nonce($_POST['wtp_import_json']??'','wtp_import_json')){ ImportExport::import_json($_FILES['json_file']??null, !empty($_POST['dry_run'])); }
    if(isset($_POST['do_import_csv']) && \wp_verify_nonce($_POST['wtp_import_csv']??'','wtp_import_csv')){ ImportExport::import_csv($_FILES['redirects_csv']??null, $_FILES['categories_csv']??null, !empty($_POST['dry_run'])); }
    echo '</div>';
  }
}
