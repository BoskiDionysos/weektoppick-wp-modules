<?php
namespace WTP\SEO\Admin; if(!defined('ABSPATH')) exit;
class MultilangAdmin{
  static function render(){
    if(!\current_user_can('manage_wtp_seo')) return;
    $loc=\get_option('wtp_locales','en,pl,it,de,fr,es,pt'); $arr=array_filter(array_map('trim',explode(',',$loc))); $sample='/sample-page/';
    echo '<div class="wrap"><h1>Multilang &amp; Hreflang</h1><p>Configured locales: <code>'.\esc_html($loc).'</code></p><p>Preview for path <code>'.$sample.'</code>:</p><ul>';
    foreach($arr as $lc){ echo '<li>'.\esc_html($lc).' → <a target="_blank" href="'.\esc_url(\home_url('/'.$lc.$sample)).'">'.\esc_html(\home_url('/'.$lc.$sample)).'</a></li>'; }
    echo '</ul><p>Note: hreflang tags are injected into &lt;head&gt; sitewide.</p></div>';
  }
}
