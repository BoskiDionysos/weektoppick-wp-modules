<?php
namespace WTP\SEO\Admin; if(!defined('ABSPATH')) exit;
class Menu{
  function __construct(){ \add_action('admin_menu',[$this,'menu']); }
  function menu(){
    if(!\current_user_can('manage_wtp_seo')) return;
    \add_menu_page('WTP SEO','WTP SEO','manage_wtp_seo','wtp-seo',[$this,'dash'],'dashicons-album',59);
    \add_submenu_page('wtp-seo','Settings','Settings','manage_wtp_seo','wtp-seo-settings',['\WTP\SEO\Admin\Settings','render']);
    \add_submenu_page('wtp-seo','Redirects','Redirects','manage_wtp_seo','wtp-seo-redirects',['\WTP\SEO\Admin\RedirectsAdmin','render']);
    \add_submenu_page('wtp-seo','404 Monitor','404 Monitor','manage_wtp_seo','wtp-seo-404',['\WTP\SEO\Admin\Monitor404','render']);
    \add_submenu_page('wtp-seo','Meta Templates','Meta Templates','manage_wtp_seo','wtp-seo-templates',['\WTP\SEO\Admin\TemplatesAdmin','render']);
    \add_submenu_page('wtp-seo','Multilang & Hreflang','Multilang & Hreflang','manage_wtp_seo','wtp-seo-multilang',['\WTP\SEO\Admin\MultilangAdmin','render']);
    \add_submenu_page('wtp-seo','Sitemaps','Sitemaps','manage_wtp_seo','wtp-seo-sitemaps',[$this,'sitemaps']);
    \add_submenu_page('wtp-seo','Analytics','Analytics','manage_wtp_seo','wtp-seo-analytics',['\WTP\SEO\Admin\AnalyticsAdmin','render']);
    \add_submenu_page('wtp-seo','Import/Export','Import/Export','manage_wtp_seo','wtp-seo-port',['\WTP\SEO\Admin\ImportExportAdmin','render']);
  }
  function dash(){ echo '<div class="wrap"><h1>WTP SEO – Dashboard</h1><p><b>Version:</b> '.\esc_html(\get_option('wtp_seo_db_version','0.3.5')).'</p><p><b>Locales:</b> '.\esc_html(\get_option('wtp_locales','en,pl,it,de,fr,es,pt')).'</p><p><a href="'.\esc_url(\home_url('/wp-sitemap.xml')).'">/wp-sitemap.xml</a></p></div>'; }
  function sitemaps(){ echo '<div class="wrap"><h1>Sitemaps</h1><p>Using native <code>/wp-sitemap.xml</code>.</p></div>'; }
}
