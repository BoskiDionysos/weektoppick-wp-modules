<?php if(!defined('WP_UNINSTALL_PLUGIN')) exit;
delete_option('wtp_locales'); delete_option('wtp_legacy_keywords'); delete_option('wtp_events');
delete_option('wtp_tpl_post_title'); delete_option('wtp_tpl_post_desc'); delete_option('wtp_tpl_page_title'); delete_option('wtp_tpl_page_desc');
delete_option('wtp_redirects'); delete_option('wtp_404_log'); delete_option('wtp_seo_db_version');
