<?php
/**
 * Plugin Name: WTP Module Manager
 * Description: Minimalny menedżer modułów dla WTP Bridge/Runner. REST: POST /wtp/v1/mods/install (X-WTP-Key). Instalacja ZIP-ów z retry/overwrite, bez autoaktywacji.
 * Version: 1.0.2
 * Author: WeekTopPick Autopilot
 * License: GPLv2 or later
 */

if ( ! defined('ABSPATH') ) exit;

class WTP_Module_Manager {
    const SLUG = 'wtp-module-manager';
    const OPTS = 'wtp_module_manager_opts';
    const LOG  = 'wtp_module_manager_log'; // max 200 wpisów

    public function __construct(){
        add_action('admin_menu',  [$this,'menu']);
        add_action('admin_init',  [$this,'register']);
        add_action('rest_api_init',[$this,'rest']);
    }

    /* ---------- Admin ---------- */

    public function menu(){
        add_menu_page(
            'WTP Module Manager',
            'WTP Module Manager',
            'manage_options',
            self::SLUG,
            [$this,'render'],
            'dashicons-admin-plugins',
            61
        );
    }

    public function register(){
        register_setting(self::SLUG, self::OPTS);
        $o = get_option(self::OPTS, []);
        if (!is_array($o)) $o = [];
        $defaults = [
            'api_key'       => wp_generate_password(32,false,false),
            'allow_install' => true,
        ];
        update_option(self::OPTS, array_merge($defaults, $o), false);
    }

    private static function log($action,$result,$details=''){
        $row = [
            'time'   => gmdate('c'),
            'action' => $action,
            'result' => $result,
            'details'=> $details
        ];
        $log = get_option(self::LOG, []);
        if(!is_array($log)) $log=[];
        array_unshift($log,$row);
        update_option(self::LOG, array_slice($log,0,200), false);
        return $row;
    }

    public function render(){
        if (!current_user_can('manage_options')) return;
        $o = get_option(self::OPTS, []);
        $o = wp_parse_args($o, ['api_key'=>'','allow_install'=>true]);
        $ping_url    = esc_html( get_rest_url(null, '/wtp/v1/mods/ping') );
        $install_url = esc_html( get_rest_url(null, '/wtp/v1/mods/install') );
        $log = get_option(self::LOG, []);
        ?>
        <div class="wrap">
            <h1>WTP Module Manager</h1>
            <p>Uwierzytelnianie: nagłówek <code>X-WTP-Key</code> musi być równy kluczowi poniżej.</p>
            <form method="post" action="options.php">
                <?php settings_fields(self::SLUG); ?>
                <table class="form-table">
                    <tr>
                        <th>API Key</th>
                        <td><input type="text" name="<?php echo self::OPTS; ?>[api_key]" value="<?php echo esc_attr($o['api_key']);?>" class="regular-text" style="width:420px;"></td>
                    </tr>
                    <tr>
                        <th>Pozwól na instalację</th>
                        <td><label><input type="checkbox" name="<?php echo self::OPTS; ?>[allow_install]" <?php checked(!empty($o['allow_install']));?>> Włączone</label></td>
                    </tr>
                </table>
                <p><button class="button button-primary">Zapisz</button></p>
            </form>

            <h2>Endpointy</h2>
            <ul>
                <li><code>GET <?php echo $ping_url; ?></code></li>
                <li><code>POST <?php echo $install_url; ?></code> — body: <code>{"url":"https://…/plugin.zip"}</code> (+ opcjonalnie <code>overwrite</code>, <code>force</code>)</li>
            </ul>

            <h2>Log</h2>
            <?php if ($log): ?>
                <table class="widefat striped">
                    <thead><tr><th>Czas (UTC)</th><th>Akcja</th><th>Wynik</th><th>Szczegóły</th></tr></thead>
                    <tbody>
                    <?php foreach ($log as $row): ?>
                        <tr>
                            <td><?php echo esc_html($row['time']);?></td>
                            <td><?php echo esc_html($row['action']);?></td>
                            <td><?php echo esc_html($row['result']);?></td>
                            <td><code style="white-space:pre-wrap;"><?php echo esc_html(is_string($row['details'])?$row['details']:wp_json_encode($row['details'], JSON_UNESCAPED_SLASHES));?></code></td>
                        </tr>
                    <?php endforeach; ?>
                    </tbody>
                </table>
            <?php else: ?>
                <p>Brak wpisów.</p>
            <?php endif; ?>
        </div>
        <?php
    }

    /* ---------- Auth ---------- */

    private function check_auth(){
        $o = get_option(self::OPTS, []);
        $key = isset($_SERVER['HTTP_X_WTP_KEY']) ? sanitize_text_field($_SERVER['HTTP_X_WTP_KEY']) : '';
        if ( empty($o['api_key']) || ! hash_equals((string)$o['api_key'], (string)$key) ){
            return new \WP_REST_Response(['ok'=>false,'error'=>'unauthorized'], 401);
        }
        return true;
    }

    /* ---------- REST ---------- */

    public function rest(){
        register_rest_route('wtp/v1', '/mods/ping', [
            'methods' => 'GET',
            'permission_callback' => '__return_true',
            'callback' => function(){
                $auth = $this->check_auth();
                if ($auth !== true) return $auth;
                return new \WP_REST_Response(['ok'=>true,'time'=>gmdate('c')], 200);
            }
        ]);

        register_rest_route('wtp/v1', '/mods/install', [
            'methods' => 'POST',
            'permission_callback' => '__return_true',
            'callback' => [$this,'rest_install']
        ]);
    }

    public function rest_install(\WP_REST_Request $req){
        $auth = $this->check_auth();
        if ($auth !== true) return $auth;

        $o = get_option(self::OPTS, []);
        if ( empty($o['allow_install']) ){
            return new \WP_REST_Response(['ok'=>false,'error'=>'install_disabled'], 403);
        }

        $url = esc_url_raw( $req->get_param('url') );
        if (!$url) return new \WP_REST_Response(['ok'=>false,'error'=>'missing url'], 400);

        // Strażnicy środowiska
        if ( defined('DISALLOW_FILE_MODS') && DISALLOW_FILE_MODS ) {
            return new \WP_REST_Response(['ok'=>false,'error'=>'file_mods_disabled'], 500);
        }
        if ( ! is_dir(WP_PLUGIN_DIR) || ! is_writable(WP_PLUGIN_DIR) ) {
            return new \WP_REST_Response(['ok'=>false,'error'=>'plugins_dir_not_writable'], 500);
        }

        // Upgrader
        require_once ABSPATH.'wp-admin/includes/file.php';
        require_once ABSPATH.'wp-admin/includes/plugin.php';
        require_once ABSPATH.'wp-admin/includes/class-wp-upgrader.php';

        $skin     = new \Automatic_Upgrader_Skin();
        $upgrader = new \Plugin_Upgrader($skin);

        $get_msgs = function() use ($skin){
            if (method_exists($skin,'get_upgrade_messages')) {
                $m = $skin->get_upgrade_messages(); return is_array($m)?implode("\n",$m):(string)$m;
            }
            return '';
        };

        $run = function(bool $clear) use ($upgrader,$url){
            if ($clear){
                // twarde nadpisanie docelowego folderu
                return $upgrader->run([
                    'package'           => $url,
                    'destination'       => WP_PLUGIN_DIR,
                    'clear_destination' => true,
                    'clear_working'     => true,
                    'hook_extra'        => [],
                ]);
            }
            return $upgrader->install($url);
        };

        $overwrite = (bool)$req->get_param('overwrite');
        $force     = (bool)$req->get_param('force');

        // 1) standard
        $result1 = $run(false);
        $msg1    = $get_msgs();

        $need_retry = false;
        $haystack1  = strtolower($msg1);
        if ( is_wp_error($result1) ) {
            $haystack1 .= ' '.strtolower($result1->get_error_message());
        }
        if ($force || $overwrite ||
            strpos($haystack1,'destination folder')!==false ||
            strpos($haystack1,'already exists')!==false ||
            strpos($haystack1,'folder exists')!==false ) {
            $need_retry = true;
        }

        $result = $result1;
        $msg2   = '';
        if ($need_retry){
            $result = $run(true);
            $msg2   = $get_msgs();
        }

        if ( is_wp_error($result) ){
            $err = ['code'=>$result->get_error_code(),'msg'=>$result->get_error_message()];
            self::log('install','fail', ['url'=>$url,'error'=>$err,'m1'=>$msg1,'m2'=>$msg2]);
            return new \WP_REST_Response([
                'ok'=>false,
                'error'=>'install_failed',
                'error_code'=>$err['code'],
                'error_msg' =>$err['msg'],
                'messages'=> trim($msg1."\n".$msg2),
            ], 500);
        }
        if (!$result){
            self::log('install','fail', ['url'=>$url,'m1'=>$msg1,'m2'=>$msg2]);
            return new \WP_REST_Response([
                'ok'=>false,
                'error'=>'install_failed',
                'messages'=> trim($msg1."\n".$msg2),
            ], 500);
        }

        self::log('install','ok', ['url'=>$url,'m1'=>$msg1,'m2'=>$msg2]);
        return new \WP_REST_Response([
            'ok'=>true,
            'installed'=>true,
            'messages'=> trim($msg1."\n".$msg2),
        ], 200);
    }
}

new WTP_Module_Manager();