<footer class="site-footer">
  <div class="container">
    <small>&copy; <?php echo date('Y'); ?> WeekTopPick</small>
  </div>
</footer>
<?php wp_footer(); ?>
</body>
</html>
