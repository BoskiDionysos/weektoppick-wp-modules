# WTP Core Theme – 1.6.4

- NEW: Category chips with 9 canonical parents and SVG icons (with fallback).
- NEW: Subchips loaded from WordPress child terms only (sorted by `wtp_order`, then A→Z).
- NEW: Language detection & cookie (`wtp_lang`) with JSON i18n fallback.
- NEW: Charity banner shown at top on first visit; moves to bottom on subsequent visits (`wtp_charity_seen` cookie).
- NEW: `selftest.txt` generator with categories, languages, icons status, charity positions, writable flag.
- Kept: language switcher with flags, layout and footer build tag.